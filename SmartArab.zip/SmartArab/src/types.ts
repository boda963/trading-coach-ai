export interface Candle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  volumeDelta?: number;
  sma20?: number | null;
  sma50?: number | null;
  ema200?: number | null;
  rsi?: number | null;
  atr?: number | null;
  macd?: { MACD?: number; signal?: number; histogram?: number } | null;
}

export interface TradeParams {
  capital: number;
  risk: number;
  leverage: number;
  symbol: string;
  timeframe: string;
  psych: PsychState;
  aiMode: string;
}

export interface PsychState {
  scoreOutOf10: number;
  stressed: boolean;
  revengeTrading: boolean;
  fomo: boolean;
  wellRested: boolean;
  tradesToday: number;
}

export interface AnalysisResult {
  action: "LONG" | "SHORT" | "NO_TRADE";
  decisionReason: string;
  trend: string;
  momentum: string;
  isTradable: boolean;
  tradeScoreOutOf10: number;
  currentRsi: number;
  shortEntryReasons: string[];
  marketStructureAnalysis: string;
  lateEntryWarning: boolean;
  badRiskRewardWarning: boolean;
  fakeBreakoutWarning?: string;
  winProbabilityPercent: number;
  entryQuality: string;
  entry: number;
  stopLoss: number;
  takeProfit: number;
  riskRewardRatio: number;
  trapDetected: string;
  psychologicalAdvice: string;
}

export interface TradeContext {
  symbol: string;
  timeframe: string;
  capital: number;
  risk: number;
  leverage: number;
}
