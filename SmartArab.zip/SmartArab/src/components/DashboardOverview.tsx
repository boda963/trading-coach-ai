import { useState, useEffect } from "react";
import { collection, query, orderBy, onSnapshot } from "firebase/firestore";
import { db, auth } from "../services/firebase";
import { handleFirestoreError, OperationType } from "../lib/firestoreErrorHandler";
import { Activity, Target, TrendingUp, TrendingDown, BookOpen, AlertCircle } from "lucide-react";
import { motion } from "motion/react";

export default function DashboardOverview() {
  const [stats, setStats] = useState({
    totalTrades: 0,
    winRate: 0,
    totalProfit: 0,
    capital: 10000,
    longTrades: 0,
    shortTrades: 0,
    fomoCount: 0,
    stressedCount: 0,
    revengeCount: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!auth.currentUser) return;
    
    console.log("[DashboardOverview] Setting up stats listener...");
    const tradesPath = `users/${auth.currentUser.uid}/trades`;
    const q = query(collection(db, tradesPath), orderBy("createdAt", "desc"));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      console.log("[DashboardOverview] Data updated, recalibrating stats...");
      const trades = snapshot.docs.map(doc => doc.data());
      
      const totalTrades = trades.length;
      let winRate = 0;
      let longTrades = 0;
      let shortTrades = 0;
      let wins = 0;
      let totalProfit = 0;
      
      let fomoCount = 0;
      let stressedCount = 0;
      let revengeCount = 0;

      trades.forEach(t => {
        if (t.action === "LONG") longTrades++;
        if (t.action === "SHORT") shortTrades++;
        if (t.status === "WON") wins++;
        totalProfit += (t.pnl || 0);
        
        if (t.psychologicalState) {
          if (t.psychologicalState.fomo) fomoCount++;
          if (t.psychologicalState.stressed) stressedCount++;
          if (t.psychologicalState.revengeTrading) revengeCount++;
        }
      });

      const closedTrades = trades.filter(t => t.status === "WON" || t.status === "LOST").length;
      if (closedTrades > 0) {
        winRate = (wins / closedTrades) * 100;
      }

      setStats({
        totalTrades,
        winRate,
        totalProfit,
        capital: 10000, // This could be dynamic from a user doc
        longTrades,
        shortTrades,
        fomoCount,
        stressedCount,
        revengeCount
      });
      setLoading(false);
    }, (error) => {
      console.error("[DashboardOverview] Snapshot error:", error);
      handleFirestoreError(error, OperationType.LIST, tradesPath);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [auth.currentUser]);

  if (loading) {
    return <div className="flex-1 flex items-center justify-center"><Activity className="w-8 h-8 text-brand-purple animate-spin" /></div>;
  }

  return (
    <div className="flex-1 overflow-y-auto p-8" dir="rtl">
      <h1 className="text-2xl font-bold mb-8 flex items-center gap-2">
        <Target className="w-6 h-6 text-brand-purple" />
        لوحة التحكم الرئيسية
      </h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} className="bg-bg-card border border-border-subtle p-6 rounded-2xl">
          <div className="flex items-center gap-4 mb-4">
             <div className="w-12 h-12 rounded-full bg-brand-purple/10 flex items-center justify-center">
               <BookOpen className="w-6 h-6 text-brand-purple" />
             </div>
             <div>
               <h3 className="text-sm text-text-muted">عدد الصفقات</h3>
               <p className="text-2xl font-bold">{stats.totalTrades}</p>
             </div>
          </div>
        </motion.div>

        <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.1 }} className="bg-bg-card border border-border-subtle p-6 rounded-2xl">
          <div className="flex items-center gap-4 mb-4">
             <div className="w-12 h-12 rounded-full bg-brand-green/10 flex items-center justify-center">
               <TrendingUp className="w-6 h-6 text-brand-green" />
             </div>
             <div>
               <h3 className="text-sm text-text-muted">نسبة النجاح</h3>
               <p className="text-2xl font-bold">{stats.winRate.toFixed(1)}%</p>
             </div>
          </div>
        </motion.div>

        <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.2 }} className="bg-bg-card border border-border-subtle p-6 rounded-2xl">
          <div className="flex items-center gap-4 mb-4">
             <div className="w-12 h-12 rounded-full bg-blue-500/10 flex items-center justify-center">
               <TrendingUp className="w-6 h-6 text-blue-500" />
             </div>
             <div>
               <h3 className="text-sm text-text-muted">صفقات شراء (LONG)</h3>
               <p className="text-2xl font-bold">{stats.longTrades}</p>
             </div>
          </div>
        </motion.div>

        <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.3 }} className="bg-bg-card border border-border-subtle p-6 rounded-2xl">
          <div className="flex items-center gap-4 mb-4">
             <div className="w-12 h-12 rounded-full bg-brand-red/10 flex items-center justify-center">
               <TrendingDown className="w-6 h-6 text-brand-red" />
             </div>
             <div>
               <h3 className="text-sm text-text-muted">صفقات بيع (SHORT)</h3>
               <p className="text-2xl font-bold">{stats.shortTrades}</p>
             </div>
          </div>
        </motion.div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-bg-card border border-border-subtle rounded-2xl p-8 shadow-sm">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-full bg-brand-purple/20 flex items-center justify-center">
              <Activity className="w-5 h-5 text-brand-purple" />
            </div>
            <h3 className="text-lg text-white font-bold">الذاكرة التحليلية للكوتش (AI Memory)</h3>
          </div>
          
          <div className="space-y-4">
            <div className={`p-4 rounded-xl border flex items-start gap-4 transition-colors ${stats.fomoCount > 0 ? "bg-brand-orange/10 border-brand-orange/30" : "bg-bg-dark border-border-subtle"}`}>
              <AlertCircle className={`w-6 h-6 shrink-0 mt-0.5 ${stats.fomoCount > 0 ? "text-brand-orange" : "text-text-muted"}`} />
              <div>
                <h4 className="font-bold mb-1 text-sm">متلازمة الخوف من تفويت الفرصة (FOMO)</h4>
                <p className="text-sm text-text-muted leading-relaxed">
                  {stats.fomoCount > 0 ? `لقد تداولت ${stats.fomoCount} مرات تحت تأثير FOMO. يرجى التركيز على التزام الخطة وعدم مطاردة السعر لتجنب الخسائر.` : `أداؤك ممتاز! لم يسجل الكوتش أي انحياز لـ FOMO في صفقاتك الحالية.`}
                </p>
              </div>
            </div>

            <div className={`p-4 rounded-xl border flex items-start gap-4 transition-colors ${stats.revengeCount > 0 ? "bg-brand-red/10 border-brand-red/30" : "bg-bg-dark border-border-subtle"}`}>
              <AlertCircle className={`w-6 h-6 shrink-0 mt-0.5 ${stats.revengeCount > 0 ? "text-brand-red" : "text-text-muted"}`} />
              <div>
                <h4 className="font-bold mb-1 text-sm">الانتقام من السوق (Revenge Trading)</h4>
                <p className="text-sm text-text-muted leading-relaxed">
                  {stats.revengeCount > 0 ? `رصد السجل ${stats.revengeCount} محاولات انتقام من السوق. التداول الانتقامي هو أسرع طريق لمرجنة الحساب.` : `رائع. أنت تتقبل الخسارة بهدوء وتلتزم بإدارة المخاطر.`}
                </p>
              </div>
            </div>

            <div className={`p-4 rounded-xl border flex items-start gap-4 transition-colors ${stats.stressedCount > 0 ? "bg-[#eab308]/10 border-[#eab308]/30" : "bg-bg-dark border-border-subtle"}`}>
              <AlertCircle className={`w-6 h-6 shrink-0 mt-0.5 ${stats.stressedCount > 0 ? "text-[#eab308]" : "text-text-muted"}`} />
              <div>
                <h4 className="font-bold mb-1 text-sm">التداول تحت الضغط (Stress)</h4>
                <p className="text-sm text-text-muted leading-relaxed">
                  {stats.stressedCount > 0 ? `قمت بتنفيذ ${stats.stressedCount} صفقات وأنت متوتر. التداول يتطلب صفاء الذهن والتركيز.` : `تحكم جيد بالانفعالات والضغط في صفقاتك المسجلة.`}
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-bg-card border border-border-subtle rounded-2xl p-8 text-center text-text-muted flex flex-col items-center justify-center min-h-[300px]">
          <Activity className="w-16 h-16 mb-4 opacity-50" />
          <h3 className="text-lg text-white font-bold mb-2">أداء التداول المتقدم</h3>
          <p className="max-w-xs leading-relaxed">سيتم قريباً توفير أداة PnL المتقدمة والرسوم البيانية لتطور رأس المال بمرور الوقت.</p>
        </div>
      </div>
    </div>
  );
}
