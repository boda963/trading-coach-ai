import { useState, useEffect } from "react";
import { collection, query, orderBy, doc, updateDoc, serverTimestamp, onSnapshot } from "firebase/firestore";
import { db, auth } from "../services/firebase";
import { handleFirestoreError, OperationType } from "../lib/firestoreErrorHandler";
import { BookOpen, CheckCircle, XCircle, Clock, Trash, TrendingUp, TrendingDown, Activity } from "lucide-react";
import toast from "react-hot-toast";
import { motion, AnimatePresence } from "motion/react";

export default function Journal() {
  const [trades, setTrades] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!auth.currentUser) return;
    
    console.log("[Journal] Setting up trades listener for user:", auth.currentUser.uid);
    const tradesPath = `users/${auth.currentUser.uid}/trades`;
    const q = query(collection(db, tradesPath), orderBy("createdAt", "desc"));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      console.log("[Journal] Snapshot received with", snapshot.size, "trades");
      const fetchedTrades = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setTrades(fetchedTrades);
      setLoading(false);
    }, (error) => {
      console.error("[Journal] Snapshot error:", error);
      handleFirestoreError(error, OperationType.LIST, tradesPath);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [auth.currentUser]);

  const updateTradeStatus = async (tradeId: string, status: string, tradeData: any) => {
    if (!auth.currentUser) return;
    const tradePath = `users/${auth.currentUser.uid}/trades/${tradeId}`;
    console.log(`[Journal] Attempting to close trade ${tradeId} as ${status}`);
    
    // Calculate PnL based on status
    let pnl = 0;
    const capitalRisked = parseFloat(tradeData.capitalRisked) || 0;
    const riskReward = parseFloat(tradeData.riskReward) || 1;

    if (status === "WON") {
      // Risked capital * Reward Ratio
      pnl = capitalRisked * riskReward;
    } else if (status === "LOST") {
      pnl = -capitalRisked;
    }

    console.log(`[Journal] Calculated PnL: ${pnl} (Risked: ${capitalRisked}, RR: ${riskReward})`);

    try {
      await updateDoc(doc(db, tradePath), { 
        status,
        pnl,
        closedAt: serverTimestamp()
      });
      console.log(`[Journal] Trade ${tradeId} updated successfully in Firebase`);
      toast.success(status === "WON" ? "مبروك! صفقة رابحة 🎉" : "تم تسجيل الخسارة. استمر في الانضباط.");
    } catch (e: any) {
      console.error("[Journal] Update trade error:", e);
      const isRulesError = e.message.includes('{') && e.message.includes('authInfo');
      toast.error(isRulesError ? "فشل التحديث: نقص الصلاحيات" : "فشل في التحديث");
    }
  };

  if (loading) {
    return <div className="flex-1 flex items-center justify-center">جاري جلب السجل...</div>;
  }

  return (
    <div className="flex-1 overflow-y-auto p-8" dir="rtl">
      <h1 className="text-2xl font-bold mb-8 flex items-center gap-2">
        <BookOpen className="w-6 h-6 text-brand-purple" />
        سجل الصفقات
      </h1>

      {/* Quick Stats Bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4 mb-6" dir="rtl">
        <div className="bg-bg-card border border-border-subtle p-4 rounded-2xl shadow-sm">
          <div className="text-[10px] uppercase font-bold text-text-muted mb-1">إجمالي الصفقات</div>
          <div className="text-xl font-black text-white">{trades.length}</div>
        </div>
        <div className="bg-bg-card border border-border-subtle p-4 rounded-2xl shadow-sm">
          <div className="text-[10px] uppercase font-bold text-text-muted mb-1">نسبة النجاح</div>
          <div className="text-xl font-black text-brand-green">
            {trades.length > 0 ? ((trades.filter(t => t.status === 'WON').length / trades.filter(t => t.status !== 'OPEN').length || 0) * 100).toFixed(1) : 0}%
          </div>
        </div>
        <div className="bg-bg-card border border-border-subtle p-4 rounded-2xl shadow-sm">
          <div className="text-[10px] uppercase font-bold text-text-muted mb-1">إجمالي الربح/الخسارة</div>
          <div className={`text-xl font-black ${trades.reduce((acc, t) => acc + (t.pnl || 0), 0) >= 0 ? 'text-brand-green' : 'text-brand-red'}`}>
            ${trades.reduce((acc, t) => acc + (t.pnl || 0), 0).toFixed(2)}
          </div>
        </div>
        <div className="bg-bg-card border border-border-subtle p-4 rounded-2xl shadow-sm">
          <div className="text-[10px] uppercase font-bold text-text-muted mb-1">أفضل صفقات</div>
          <div className="text-xl font-black text-brand-purple">
            ${Math.max(...trades.map(t => t.pnl || 0), 0).toFixed(2)}
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <AnimatePresence>
          {trades.length === 0 ? (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="bg-bg-card p-10 text-center rounded-2xl border border-border-subtle text-text-muted">
              لا توجد صفقات محفوظة بعد. قم بتحليل السوق واحفظ بعض الصفقات في سجل التداول الخاص بك!
            </motion.div>
          ) : trades.map((trade) => (
            <motion.div 
              key={trade.id} 
              layout
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className={`bg-bg-card border rounded-xl p-6 flex flex-col md:flex-row gap-6 relative shadow-sm transition-colors ${
                trade.status === "WON" ? "border-brand-green/30" : 
                trade.status === "LOST" ? "border-brand-red/30" : "border-border-subtle"
              }`}
            >
              <div className="flex-1 space-y-4">
                 <div className="flex justify-between items-center">
                   <div className="flex items-center gap-3">
                     <div className={`px-3 py-1 rounded font-bold text-sm tracking-widest ${
                       trade.action === "LONG" ? "bg-brand-green/20 text-brand-green" :
                       trade.action === "SHORT" ? "bg-brand-red/20 text-brand-red" : "bg-text-muted/20 text-text-main"
                     }`}>
                       {trade.action}
                     </div>
                     <h3 className="font-bold text-lg" dir="ltr">{trade.pair}</h3>
                     <span className="text-sm text-text-muted bg-bg-dark px-2 py-0.5 rounded border border-border-subtle">{trade.timeframe}</span>
                   </div>
                   
                   <div className="text-sm text-text-muted" dir="ltr">
                     {trade.createdAt && typeof trade.createdAt.toDate === 'function' 
                        ? trade.createdAt.toDate().toLocaleString('en-US', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) 
                        : (trade.createdAt ? new Date(trade.createdAt).toLocaleString('en-US', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : '')}
                   </div>
                 </div>

                 <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mt-4">
                   <div className="bg-bg-dark rounded p-3 text-center border border-border-subtle">
                     <div className="text-xs text-text-muted mb-1">دخول</div>
                     <div className="font-mono text-sm" dir="ltr">{trade.entry}</div>
                   </div>
                   <div className="bg-bg-dark rounded p-3 text-center border border-border-subtle">
                     <div className="text-xs text-text-muted mb-1">الهدف</div>
                     <div className="font-mono text-sm text-brand-green" dir="ltr">{trade.takeProfit}</div>
                   </div>
                   <div className="bg-bg-dark rounded p-3 text-center border border-border-subtle">
                     <div className="text-xs text-text-muted mb-1">وقف الخسارة</div>
                     <div className="font-mono text-sm text-brand-red" dir="ltr">{trade.stopLoss}</div>
                   </div>
                   <div className="bg-bg-dark rounded p-3 text-center border border-border-subtle">
                     <div className="text-xs text-text-muted mb-1">نسبة العائد</div>
                     <div className="font-mono text-sm text-white" dir="ltr">1 : {trade.riskReward}</div>
                   </div>
                   <div className="bg-bg-dark rounded p-3 text-center border border-border-subtle">
                     <div className="text-xs text-text-muted mb-1">PnL</div>
                     <div className={`font-mono text-sm font-bold ${trade.pnl > 0 ? 'text-brand-green' : trade.pnl < 0 ? 'text-brand-red' : 'text-white'}`} dir="ltr">
                       {trade.pnl > 0 ? '+' : ''}{trade.pnl?.toFixed(2) || '0.00' }
                     </div>
                   </div>
                 </div>

                 <div className="mt-4 p-4 bg-bg-dark rounded-lg border border-border-subtle">
                   <h4 className="text-xs font-bold text-text-muted mb-2">تعليل الصفقة:</h4>
                   <p className="text-sm">{trade.aiReasoning}</p>
                 </div>
              </div>

              <div className="w-full md:w-48 shrink-0 flex flex-col gap-3 justify-center items-center p-4 bg-bg-dark rounded-xl border border-border-subtle text-center">
                <h4 className="text-xs text-text-muted font-bold mb-2">حالة الصفقة</h4>
                
                {trade.status === "OPEN" ? (
                   <>
                     <Clock className="w-8 h-8 text-brand-purple mb-2 opacity-50" />
                     <p className="font-bold mb-4">مفتوحة الآن</p>
                     <div className="grid grid-cols-1 w-full gap-2">
                       <button onClick={() => updateTradeStatus(trade.id, "WON", trade)} className="w-full py-2 bg-brand-green/10 text-brand-green border border-brand-green/30 hover:bg-brand-green hover:text-white rounded transition text-xs font-bold flex items-center justify-center gap-1">
                         <TrendingUp className="w-3 h-3" /> إغلاق بربح
                       </button>
                       <button onClick={() => updateTradeStatus(trade.id, "LOST", trade)} className="w-full py-2 bg-brand-red/10 text-brand-red border border-brand-red/30 hover:bg-brand-red hover:text-white rounded transition text-xs font-bold flex items-center justify-center gap-1">
                         <TrendingDown className="w-3 h-3" /> إغلاق بخسارة
                       </button>
                     </div>
                   </>
                ) : trade.status === "WON" ? (
                   <motion.div initial={{ scale: 0.5 }} animate={{ scale: 1 }} className="flex flex-col items-center">
                     <CheckCircle className="w-12 h-12 text-brand-green mb-2" />
                     <p className="font-bold text-brand-green">صفقة رابحة</p>
                     <p className="text-[10px] text-text-muted mt-1">PnL: +${trade.pnl?.toFixed(2)}</p>
                   </motion.div>
                ) : (
                   <motion.div initial={{ scale: 0.5 }} animate={{ scale: 1 }} className="flex flex-col items-center">
                     <XCircle className="w-12 h-12 text-brand-red mb-2" />
                     <p className="font-bold text-brand-red">صفقة خاسرة</p>
                     <p className="text-[10px] text-text-muted mt-1">PnL: -${Math.abs(trade.pnl || 0).toFixed(2)}</p>
                   </motion.div>
                )}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
