import { useEffect, useRef } from 'react';
import { sendTradingNotification } from './NotificationManager';
import { auth } from '../services/firebase';

const PAIR_COOLDOWN = 30 * 60 * 1000; // 30 minutes cooldown per pair

interface ScannerConfig {
  enabled: boolean;
  minConfidence: number;
  scannerEnabled: boolean;
  scannerPairs: 'TOP10' | 'TOP50' | 'ALL';
}

export default function ScannerDaemon() {
  const cooldowns = useRef<{ [key: string]: number }>({});
  const isScanning = useRef(false);

  useEffect(() => {
    const scannerInterval = setInterval(() => {
      runScan();
    }, 60000 * 5); // Run every 5 minutes

    return () => clearInterval(scannerInterval);
  }, []);

  const runScan = async () => {
    if (isScanning.current || !auth.currentUser) return;
    
    const settingsRaw = localStorage.getItem('notificationSettings');
    const settings: ScannerConfig = settingsRaw ? JSON.parse(settingsRaw) : { 
      scannerEnabled: true, 
      scannerPairs: 'TOP10', 
      minConfidence: 80 
    };

    if (!settings.scannerEnabled) return;

    console.log("[ScannerDaemon] Starting market scan...", settings.scannerPairs);
    isScanning.current = true;

    try {
      // 1. Get pairs to scan
      let pairs = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'ADAUSDT', 'XRPUSDT', 'DOTUSDT', 'DOGEUSDT', 'MATICUSDT', 'LINKUSDT'];
      
      if (settings.scannerPairs === 'TOP50' || settings.scannerPairs === 'ALL') {
        try {
          const tickerRes = await fetch('https://api.binance.com/api/v3/ticker/24hr');
          const tickers = await tickerRes.json();
          const usdtPairs = tickers
            .filter((t: any) => t.symbol.endsWith('USDT'))
            .sort((a: any, b: any) => parseFloat(b.quoteVolume) - parseFloat(a.quoteVolume));
          
          const limit = settings.scannerPairs === 'TOP50' ? 50 : 100;
          pairs = usdtPairs.slice(0, limit).map((t: any) => t.symbol);
        } catch (e) {
          console.error("[ScannerDaemon] Failed to fetch ticker", e);
        }
      }

      // 2. Perform quick technical scan for each pair
      for (const pair of pairs) {
        // Skip if in cooldown
        if (cooldowns.current[pair] && Date.now() - cooldowns.current[pair] < PAIR_COOLDOWN) continue;

        try {
          // Fetch 1h candles
          const res = await fetch(`/api/market?symbol=${pair}&interval=1h&limit=20`);
          if (!res.ok) continue;
          const candles = await res.json();
          
          if (!candles || candles.length < 5) continue;

          const last = candles[candles.length - 1];
          const prev = candles[candles.length - 2];
          
          // Simple heuristic: Big price move or unusual volume
          const priceChange = Math.abs(last.close - prev.close) / prev.close;
          const volSpike = last.volume > (candles.reduce((acc: number, c: any) => acc + c.volume, 0) / candles.length) * 2;

          if (priceChange > 0.02 || volSpike) {
            console.log(`[ScannerDaemon] Potential signal on ${pair}, triggering AI...`);
            
            // Trigger AI Analysis for this pair
            const aiRes = await fetch("/api/gemini/analyze", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ 
                candles,
                params: { symbol: pair, timeframe: '1h', aiMode: 'Sniper' }
              })
            });

            const data = await aiRes.json();
            if (data && data.winProbabilityPercent >= settings.minConfidence && (data.action === 'LONG' || data.action === 'SHORT')) {
              console.log(`[ScannerDaemon] Strong AI Signal found for ${pair}: ${data.action} (${data.winProbabilityPercent}%)`);
              
              sendTradingNotification(`🚨 فرصة ${data.action} قوية على ${pair}`, {
                body: `الثقة: ${data.winProbabilityPercent}% | فريم: 1h\nالهدف: ${data.takeProfit}\nوقف الخسارة: ${data.stopLoss}`,
                icon: '/favicon.ico'
              });

              cooldowns.current[pair] = Date.now();
            }
          }
        } catch (err) {
          console.error(`[ScannerDaemon] Error scanning ${pair}`, err);
        }
        
        // Small delay between pairs to avoid rate limits
        await new Promise(r => setTimeout(r, 500));
      }
    } catch (err) {
      console.error("[ScannerDaemon] Scan error", err);
    } finally {
      isScanning.current = false;
      console.log("[ScannerDaemon] Scan finished.");
    }
  };

  return null;
}
