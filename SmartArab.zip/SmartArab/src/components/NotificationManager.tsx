import { useState, useEffect } from 'react';
import { Bell, Shield, X, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import toast from 'react-hot-toast';

export default function NotificationManager() {
  const [permission, setPermission] = useState<NotificationPermission>(
    typeof Notification !== 'undefined' ? Notification.permission : 'default'
  );
  const [showPrompt, setShowPrompt] = useState(false);

  useEffect(() => {
    console.log("[NotificationManager] Checking permission:", Notification.permission);
    // Check if we should show the prompt
    const hasSeenPrompt = localStorage.getItem('hasSeenNotificationPrompt');
    if (permission === 'default' && !hasSeenPrompt) {
      const timer = setTimeout(() => {
        console.log("[NotificationManager] Showing permission prompt");
        setShowPrompt(true);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [permission]);

  const requestPermission = async () => {
    if (typeof Notification === 'undefined') {
      console.warn("[NotificationManager] Notifications not supported");
      return;
    }
    
    console.log("[NotificationManager] Requesting permission...");
    try {
      const result = await Notification.requestPermission();
      console.log("[NotificationManager] Permission result:", result);
      setPermission(result);
      localStorage.setItem('hasSeenNotificationPrompt', 'true');
      setShowPrompt(false);
      
      if (result === 'granted') {
        toast.success('تم تفعيل الإشعارات بنجاح! ستصلك أقوى الفرص فوراً.', { icon: '🔔' });
        new Notification('تريدينج كوتش AI', {
          body: 'شكراً لتفعيل الإشعارات! سنقوم بتنبيهك عند وجود فرصة قوية.',
          icon: '/favicon.ico'
        });
      } else if (result === 'denied') {
        toast.error('تم رفض الإشعارات. يمكنك تفعيلها من إعدادات المتصفح.');
      }
    } catch (error) {
      console.error('[NotificationManager] Error requesting notification permission:', error);
    }
  };

  const skipPrompt = () => {
    localStorage.setItem('hasSeenNotificationPrompt', 'true');
    setShowPrompt(false);
  };

  return (
    <AnimatePresence>
      {showPrompt && (
        <motion.div
          initial={{ opacity: 0, y: 50, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9 }}
          className="fixed bottom-20 md:bottom-8 left-4 right-4 md:left-auto md:right-8 md:w-96 bg-bg-card border border-brand-purple/50 rounded-2xl shadow-2xl z-[100] overflow-hidden"
          dir="rtl"
        >
          <div className="bg-brand-purple/10 p-4 border-b border-brand-purple/20 flex justify-between items-center">
            <div className="flex items-center gap-2 text-brand-purple font-bold">
              <Bell className="w-5 h-5" />
              <span>تفعيل التنبيهات الذكية</span>
            </div>
            <button onClick={skipPrompt} className="text-text-muted hover:text-white transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>
          
          <div className="p-6">
            <p className="text-sm text-text-main mb-4 leading-relaxed">
              هل ترغب في استقبال إشعارات فورية عند اكتشاف الذكاء الاصطناعي لفرص قوية (Signals) أو اختراقات سعرية هامة؟
            </p>
            
            <div className="space-y-3 mb-6">
              <div className="flex items-center gap-3 text-xs text-text-muted">
                <Check className="w-4 h-4 text-brand-green" />
                <span>إشعارات فقط للفرص عالية الثقة (Confidence {">"} 80%)</span>
              </div>
              <div className="flex items-center gap-3 text-xs text-text-muted">
                <Shield className="w-4 h-4 text-brand-green" />
                <span>بدون إزعاج أو رسائل Spam</span>
              </div>
            </div>
            
            <div className="flex gap-3">
              <button
                onClick={requestPermission}
                className="flex-1 bg-brand-purple text-white py-3 rounded-xl font-bold hover:bg-opacity-90 transition-all shadow-lg shadow-brand-purple/20"
              >
                تفعيل الآن
              </button>
              <button
                onClick={skipPrompt}
                className="flex-1 bg-bg-dark border border-border-subtle text-text-muted py-3 rounded-xl font-bold hover:bg-border-subtle transition-all"
              >
                لاحقاً
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// Utility to send notifications
export const sendTradingNotification = (title: string, options: NotificationOptions) => {
  if (typeof Notification === 'undefined' || Notification.permission !== 'granted') return;

  const savedSettings = localStorage.getItem('notificationSettings');
  const config = savedSettings ? JSON.parse(savedSettings) : { enabled: true, minConfidence: 80, soundEnabled: true };

  if (!config.enabled) return;

  // Extract confidence from body if possible for filtering (though triggered by dashboard mostly)
  new Notification(title, {
    ...options,
    icon: options.icon || '/favicon.ico',
    badge: '/favicon.ico',
  });
  
  if (config.soundEnabled) {
    try {
      const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
      audio.volume = 0.3;
      audio.play().catch(() => {});
    } catch (e) {}
  }
};
