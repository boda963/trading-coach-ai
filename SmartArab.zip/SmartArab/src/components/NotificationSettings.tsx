import { useState, useEffect } from 'react';
import { Bell, BellOff, Volume2, VolumeX, ShieldCheck } from 'lucide-react';
import { motion } from 'motion/react';
import toast from 'react-hot-toast';

interface NotificationConfig {
  enabled: boolean;
  minConfidence: number;
  soundEnabled: boolean;
  scannerEnabled: boolean;
  scannerPairs: 'TOP10' | 'TOP50' | 'ALL';
}

export default function NotificationSettings() {
  const [isOpen, setIsOpen] = useState(false);
  const [permissionStatus, setPermissionStatus] = useState(
    typeof Notification !== 'undefined' ? Notification.permission : 'default'
  );

  const [config, setConfig] = useState<NotificationConfig>(() => {
    const saved = localStorage.getItem('notificationSettings');
    return saved ? JSON.parse(saved) : {
      enabled: Notification.permission === 'granted',
      minConfidence: 80,
      soundEnabled: true,
      scannerEnabled: true,
      scannerPairs: 'TOP10',
    };
  });

  useEffect(() => {
    localStorage.setItem('notificationSettings', JSON.stringify(config));
  }, [config]);

  const requestPermissionManual = async () => {
    if (typeof Notification === 'undefined') return;
    const result = await Notification.requestPermission();
    setPermissionStatus(result);
    if (result === 'granted') {
      setConfig(prev => ({ ...prev, enabled: true }));
      toast.success("تم تفعيل الإذن بنجاح");
    } else {
      toast.error("تم رفض الإذن. يرجى تفعيله من إعدادات المتصفح.");
    }
  };

  const toggleConfig = (key: keyof NotificationConfig) => {
    setConfig(prev => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div className="w-full" dir="rtl">
      <div className="flex gap-2 mb-2">
        <button 
          onClick={() => setIsOpen(!isOpen)}
          className="flex-1 flex items-center justify-between p-3 rounded-lg bg-bg-dark border border-border-subtle hover:border-brand-purple transition-all group"
        >
          <div className="flex items-center gap-2">
            {config.enabled ? <Bell className="w-4 h-4 text-brand-purple" /> : <BellOff className="w-4 h-4 text-text-muted" />}
            <span className="text-xs font-bold text-text-main">إعدادات التنبيهات</span>
          </div>
          <div className={`w-2 h-2 rounded-full ${config.enabled ? 'bg-brand-green' : 'bg-brand-red'} shadow-[0_0_8px_rgba(52,199,89,0.5)]`} />
        </button>
        
        {permissionStatus !== 'granted' && (
          <button 
            onClick={requestPermissionManual}
            className="px-3 bg-brand-purple/10 border border-brand-purple/30 rounded-lg text-[10px] font-bold text-brand-purple hover:bg-brand-purple hover:text-white transition-all whitespace-nowrap"
          >
            طلب الإذن
          </button>
        )}
      </div>

      {isOpen && (
        <motion.div 
          initial={{ opacity: 0, y: -10 }} 
          animate={{ opacity: 1, y: 0 }}
          className="p-4 bg-bg-dark border border-border-subtle rounded-lg space-y-4"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-text-muted">تفعيل الإشعارات</span>
            <button 
              onClick={() => toggleConfig('enabled')}
              className={`w-10 h-5 rounded-full relative transition-colors ${config.enabled ? 'bg-brand-purple' : 'bg-border-subtle'}`}
            >
              <div className={`absolute top-1 w-3 h-3 rounded-full bg-white transition-all ${config.enabled ? 'right-1' : 'right-6'}`} />
            </button>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold text-text-muted">الماسح التلقائي للأزواج</span>
            <button 
              onClick={() => toggleConfig('scannerEnabled')}
              className={`w-10 h-5 rounded-full relative transition-colors ${config.scannerEnabled ? 'bg-brand-purple' : 'bg-border-subtle'}`}
            >
              <div className={`absolute top-1 w-3 h-3 rounded-full bg-white transition-all ${config.scannerEnabled ? 'right-1' : 'right-6'}`} />
            </button>
          </div>

          {config.scannerEnabled && (
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-text-muted">نطاق البحث</label>
              <div className="grid grid-cols-3 gap-1">
                {(['TOP10', 'TOP50', 'ALL'] as const).map(p => (
                  <button
                    key={p}
                    onClick={() => setConfig(prev => ({ ...prev, scannerPairs: p }))}
                    className={`py-1 text-[10px] rounded border transition-all ${config.scannerPairs === p ? 'bg-brand-purple border-brand-purple text-white' : 'bg-bg-card border-border-subtle text-text-muted'}`}
                  >
                    {p === 'TOP10' ? 'أفضل 10' : p === 'TOP50' ? 'أفضل 50' : 'الكل'}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="space-y-2">
            <div className="flex justify-between text-[11px] font-bold text-text-muted">
              <span>حد الثقة الأدنى (AI Filtering)</span>
              <span className="text-brand-purple">{config.minConfidence}%</span>
            </div>
            <input 
              type="range" 
              min="50" 
              max="95" 
              step="5"
              value={config.minConfidence} 
              onChange={(e) => setConfig(prev => ({ ...prev, minConfidence: Number(e.target.value) }))}
              className="w-full accent-brand-purple h-1 bg-border-subtle rounded-lg appearance-none cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between border-t border-border-subtle pt-3">
             <div className="flex items-center gap-2 text-[11px] font-bold text-text-muted">
               {config.soundEnabled ? <Volume2 className="w-3 h-3 text-brand-purple" /> : <VolumeX className="w-3 h-3" />}
               <span>تنبيه صوتي</span>
             </div>
             <button 
              onClick={() => toggleConfig('soundEnabled')}
              className={`w-8 h-4 rounded-full relative transition-colors ${config.soundEnabled ? 'bg-brand-purple' : 'bg-border-subtle'}`}
            >
              <div className={`absolute top-0.5 w-3 h-3 rounded-full bg-white transition-all ${config.soundEnabled ? 'right-0.5' : 'right-4.5'}`} />
            </button>
          </div>

          <div className="flex items-center gap-2 mt-4 p-2 bg-brand-purple/5 rounded border border-brand-purple/20">
             <ShieldCheck className="w-3 h-3 text-brand-purple shrink-0" />
             <p className="text-[9px] text-text-muted leading-relaxed">
               سيقوم النظام الآن بمسح متعدد للأزواج وإرسال إشعارات للفرص عالية الاحتمالية.
             </p>
          </div>
        </motion.div>
      )}
    </div>
  );
}
