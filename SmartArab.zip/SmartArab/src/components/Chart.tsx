import React, { useEffect, useRef } from 'react';
import { createChart, IChartApi, ISeriesApi, Time, CandlestickSeries, LineSeries, HistogramSeries } from 'lightweight-charts';
import type { Candle } from '../types';

interface ChartProps {
  data: any[];
}

export function Chart({ data }: ChartProps) {
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const seriesRef = useRef<ISeriesApi<"Candlestick"> | null>(null);
  const sma20Ref = useRef<ISeriesApi<"Line"> | null>(null);
  const sma50Ref = useRef<ISeriesApi<"Line"> | null>(null);
  const volumeRef = useRef<ISeriesApi<"Histogram"> | null>(null);

  useEffect(() => {
    if (!chartContainerRef.current) return;

    const chart = createChart(chartContainerRef.current, {
      layout: {
        background: { color: 'transparent' },
        textColor: '#94a3b8',
      },
      grid: {
        vertLines: { color: '#1e293b' },
        horzLines: { color: '#1e293b' },
      },
      crosshair: {
        mode: 0,
      },
      timeScale: {
        timeVisible: true,
        secondsVisible: false,
      },
      autoSize: true,
    });

    chartRef.current = chart;

    const candlestickSeries = chart.addSeries(CandlestickSeries, {
      upColor: '#00e676',
      downColor: '#ff3d00',
      borderVisible: false,
      wickUpColor: '#00e676',
      wickDownColor: '#ff3d00',
    });
    seriesRef.current = candlestickSeries;

    const sma20Series = chart.addSeries(LineSeries, {
      color: '#2962FF',
      lineWidth: 2,
    });
    sma20Ref.current = sma20Series;

    const sma50Series = chart.addSeries(LineSeries, {
      color: '#FFD600',
      lineWidth: 2,
    });
    sma50Ref.current = sma50Series;
    
    // Volume series needs to be attached to its own price scale or autoScale false so it stays at bottom
    const volumeSeries = chart.addSeries(HistogramSeries, {
      color: '#26a69a',
      priceFormat: {
          type: 'volume',
      },
      priceScaleId: '',
    });
    volumeSeries.priceScale().applyOptions({
        scaleMargins: {
            top: 0.8, // highest point of the series will be at 80% of the chart height
            bottom: 0,
        },
    });
    volumeRef.current = volumeSeries;

    const formattedData = data.map(item => ({
      ...item,
      time: item.time as Time
    }));
    candlestickSeries.setData(formattedData);
    
    // Set SMA and Volume
    sma20Series.setData(formattedData.filter(d => d.sma20).map(d => ({ time: d.time, value: d.sma20 })));
    sma50Series.setData(formattedData.filter(d => d.sma50).map(d => ({ time: d.time, value: d.sma50 })));
    volumeSeries.setData(formattedData.map(d => ({ 
      time: d.time, 
      value: d.volume, 
      color: d.close >= d.open ? 'rgba(0, 230, 118, 0.5)' : 'rgba(255, 61, 0, 0.5)' 
    })));

    return () => {
      chart.remove();
    };
  }, [data]);

  // Handle data updates
  useEffect(() => {
    if (seriesRef.current && data.length > 0) {
      const formattedData = data.map(item => ({
        ...item,
        time: item.time as Time
      }));
      seriesRef.current.setData(formattedData);
      
      if (sma20Ref.current) sma20Ref.current.setData(formattedData.filter(d => d.sma20).map(d => ({ time: d.time, value: d.sma20 })));
      if (sma50Ref.current) sma50Ref.current.setData(formattedData.filter(d => d.sma50).map(d => ({ time: d.time, value: d.sma50 })));
      if (volumeRef.current) volumeRef.current.setData(formattedData.map(d => ({ 
        time: d.time, 
        value: d.volume, 
        color: d.close >= d.open ? 'rgba(0, 230, 118, 0.5)' : 'rgba(255, 61, 0, 0.5)' 
      })));
    }
  }, [data]);

  return <div ref={chartContainerRef} className="w-full h-full min-h-[400px]" />;
}
