import { useState, useEffect, useRef } from "react";
import { Chart } from "./Chart";
import { Bot, Crosshair, TrendingUp, AlertTriangle, Activity, MessageSquare, Send, CheckCircle, Save } from "lucide-react";
import type { Candle, PsychState, AnalysisResult } from "../types";
import { doc, setDoc, serverTimestamp, getDoc, addDoc, query, orderBy, onSnapshot, collection } from "firebase/firestore";
import { db, auth } from "../services/firebase";
import { handleFirestoreError, OperationType } from "../lib/firestoreErrorHandler";
import toast from "react-hot-toast";
import { motion, AnimatePresence } from "motion/react";
import { sendTradingNotification } from "./NotificationManager";
import NotificationSettings from "./NotificationSettings";

export default function TradingDashboard() {
  const [symbol, setSymbol] = useState("BTCUSDT");
  const [timeframe, setTimeframe] = useState("15m");
  const [candles, setCandles] = useState<Candle[]>([]);
  const [loading, setLoading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);

  // Risk parameters - using strings for better input handling
  const [capitalInput, setCapitalInput] = useState("10000");
  const [riskInput, setRiskInput] = useState("1");
  const [leverageInput, setLeverageInput] = useState("5");
  
  const capital = parseFloat(capitalInput) || 0;
  const riskPercent = parseFloat(riskInput) || 0;
  const leverage = parseFloat(leverageInput) || 1;

  const [aiMode, setAiMode] = useState(() => localStorage.getItem("aiMode") || "Sniper");
  const [autoUpdate, setAutoUpdate] = useState(false);
  const [lastUpdateTime, setLastUpdateTime] = useState<Date | null>(null);
  const [showIndicators, setShowIndicators] = useState(true);
  const [aiAutoAnalysis, setAiAutoAnalysis] = useState(() => localStorage.getItem("aiAutoAnalysis") || "On Candle Close");
  const [lastAnalysisTime, setLastAnalysisTime] = useState<Date | null>(null);
  
  // Update local storage when AI Mode and AI Auto Analysis change
  useEffect(() => {
    localStorage.setItem("aiMode", aiMode);
    localStorage.setItem("aiAutoAnalysis", aiAutoAnalysis);
  }, [aiMode, aiAutoAnalysis]);

  // Psych test state
  const [psychOpen, setPsychOpen] = useState(false);
  const [psychState, setPsychState] = useState<PsychState>({
    scoreOutOf10: 7,
    stressed: false,
    revengeTrading: false,
    fomo: false,
    wellRested: true,
    tradesToday: 0
  });
  const [psychTestPassed, setPsychTestPassed] = useState<boolean | null>(null);
  
  // Chat state
  const [chatOpen, setChatOpen] = useState(false);
  const [chatMessage, setChatMessage] = useState("");
  const [chatHistory, setChatHistory] = useState<{role: string, content: string}[]>([]);
  const [chatLoading, setChatLoading] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const [tradeSaved, setTradeSaved] = useState(false);

  useEffect(() => {
    fetchMarketData();
    // Reset analysis when changing symbol or timeframe
    setAnalysis(null);
    setTradeSaved(false);
  }, [symbol, timeframe]);

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatHistory]);

  const prevCandlesRef = useRef<Candle[]>([]);

  // Auto Update logic for Market Data ONLY
  useEffect(() => {
    let intervalId: NodeJS.Timeout;
    
    if (autoUpdate) {
      intervalId = setInterval(async () => {
        try {
          const res = await fetch(`/api/market?symbol=${symbol}&interval=${timeframe}`);
          if (res.ok) {
            const data = await res.json();
            const currentCandles = Array.isArray(data) ? data : (data.candles || []);
            setCandles(currentCandles);
            setLastUpdateTime(new Date());
          }
        } catch (e) {
          toast.error("تعذر تحديث البيانات، سيتم المحاولة مرة أخرى.", { id: 'auto-update-err', duration: 3000 });
        }
      }, 5000); // 5 seconds
    }
    
    return () => clearInterval(intervalId);
  }, [autoUpdate, symbol, timeframe]);

  // AI Auto Analysis trigger logic
  useEffect(() => {
    if (!analysis || !psychTestPassed || !auth.currentUser || analyzing || candles.length === 0) {
      prevCandlesRef.current = candles;
      return;
    }

    if (aiAutoAnalysis === 'Off') {
       prevCandlesRef.current = candles;
       return;
    }

    const prevCandles = prevCandlesRef.current;
    
    // Safety check - need previous data
    if (prevCandles.length > 0) {
      const prevLast = prevCandles[prevCandles.length - 1];
      const currLast = candles[candles.length - 1];
      
      let shouldAnalyze = false;

      if (aiAutoAnalysis === 'On Candle Close') {
         // Different open times means a new candle started, meaning previous one closed
         if (prevLast.time !== currLast.time) {
            shouldAnalyze = true;
         }
      } 
      else if (aiAutoAnalysis === 'On Strong Signal Only') {
         // Candle Close
         if (prevLast.time !== currLast.time) {
            shouldAnalyze = true;
         } else {
           // Big price change (> 0.5%)
           const priceDiff = Math.abs(currLast.close - prevLast.close) / prevLast.close;
           if (priceDiff > 0.005) {
              shouldAnalyze = true;
           }
           // Or big volume spike (e.g. 2x previous)
           else if (currLast.volume > (prevCandles[prevCandles.length - 2]?.volume || 0) * 2) {
              shouldAnalyze = true;
           }
         }
      }
      else if (aiAutoAnalysis === 'Every 5 Minutes') {
         if (lastAnalysisTime) {
            const diffMs = new Date().getTime() - lastAnalysisTime.getTime();
            if (diffMs >= 5 * 60 * 1000) {
               shouldAnalyze = true;
            }
         } else {
            shouldAnalyze = true;
         }
      }

      if (shouldAnalyze) {
         triggerAiAnalysis(candles);
      }
    }
    
    prevCandlesRef.current = candles;
  }, [candles, aiAutoAnalysis, analysis, psychTestPassed, auth.currentUser, lastAnalysisTime]);

  const triggerAiAnalysis = async (currentCandles: Candle[]) => {
    if (!psychTestPassed || !auth.currentUser || analyzing || currentCandles.length === 0) return false;
    
    // Daily Limit Check
    if (psychState.tradesToday >= 5 && !confirm("لقد وصلت للحد الأقصى الموصى به من الصفقات اليوم (5 صفقات). الاستمرار قد يؤدي لقرارات متهورة. هل أنت متأكد؟")) {
      return false;
    }

    setAnalyzing(true);
    try {
      const res = await fetch("/api/gemini/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          prompt: "Analyze the current market", 
          candles: currentCandles,
          params: { capital, risk: riskPercent, leverage, symbol, timeframe, psych: psychState, aiMode }
        })
      });
      
      const data = await res.json();
      if (data && !data.error) {
        setAnalysis(data);
        setLastAnalysisTime(new Date());

        // Send notification for strong signals
        const savedSettings = localStorage.getItem('notificationSettings');
        const config = savedSettings ? JSON.parse(savedSettings) : { minConfidence: 80 };
        
        if (data.winProbabilityPercent >= config.minConfidence && (data.action === 'LONG' || data.action === 'SHORT')) {
          sendTradingNotification(`🚨 فرصة ${data.action} قوية على ${symbol}`, {
            body: `الثقة: ${data.winProbabilityPercent}% | فريم: ${timeframe}\nالهدف: ${data.takeProfit}\nوقف الخسارة: ${data.stopLoss}`,
            icon: '/favicon.ico'
          });
        }
        
        return true;
      }
      if (data && data.error) {
        toast.error(data.error, { id: 'auto-update-err', duration: 4000 });
      }
      return false;
    } catch (e) {
      return false;
    } finally {
      setAnalyzing(false);
    }
  };

  const fetchMarketData = async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/market?symbol=${symbol}&interval=${timeframe}`);
      if (res.ok) {
        const data = await res.json();
        setCandles(Array.isArray(data) ? data : (data.candles || []));
        setLastUpdateTime(new Date());
      } else {
        toast.error("فشل جلب بيانات السوق");
      }
    } catch (e) {
      console.error(e);
      toast.error("حدث خطأ أثناء جلب البيانات");
    } finally {
      setLoading(false);
    }
  };

  const submitPsychTest = () => {
    const passed = psychState.scoreOutOf10 >= 5 && !psychState.stressed && !psychState.revengeTrading && !psychState.fomo;
    setPsychTestPassed(passed);
    setPsychOpen(false);
    
    if (passed) {
      toast.success("أنت مستعد للتداول. ركز على الفرص المتاحة.", { id: "psych-passed", icon: '🧠' });
    } else {
      toast.error("حالتك النفسية غير مستقرة. ننصح بالابتعاد عن الشاشة اليوم.", { id: "psych-failed", duration: 5000 });
    }
  };

  const handleAnalyze = async () => {
    if (psychTestPassed === null) {
      setPsychOpen(true);
      return;
    }

    if (psychTestPassed === false) {
      toast.error("لا يمكن تفعيل المساعد لأن حالتك النفسية غير مناسبة. خذ استراحة.");
      return;
    }

    if (!auth.currentUser) {
      toast.error("يجب تسجيل الدخول لاستخدام التحليل الذكي");
      return;
    }

    toast.loading("يتم الآن تحليل السوق...", { id: "analyze" });
    const success = await triggerAiAnalysis(candles);
    if (success) {
      toast.success("تم التحليل بنجاح", { id: "analyze" });
    } else {
      toast.error("فشل التحليل", { id: "analyze" });
    }
  };

  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [chatHistory, chatLoading]);

  // Load chat history from Firebase
  useEffect(() => {
    if (!auth.currentUser) return;
    const q = query(
      collection(db, `users/${auth.currentUser.uid}/chat`),
      orderBy("timestamp", "asc")
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const history = snapshot.docs.map(doc => doc.data() as { role: string; content: string });
      if (history.length > 0) {
        setChatHistory(history);
      }
    });
    return () => unsubscribe();
  }, [auth.currentUser]);

  const sendChatMessage = async () => {
    if (!chatMessage.trim() || chatLoading || !auth.currentUser) return;

    const userMsg = { role: "user", content: chatMessage, timestamp: serverTimestamp() };
    const tempMsg = chatMessage;
    setChatMessage("");
    setChatLoading(true);

    try {
      // Save local user message for instant feedback
      await addDoc(collection(db, `users/${auth.currentUser.uid}/chat`), userMsg);

      const res = await fetch("/api/gemini/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          message: tempMsg, 
          history: chatHistory.slice(-10), // Send last 10 messages for context
          context: { analysis, symbol, timeframe, balance: capital, tradesToday: psychState.tradesToday }
        })
      });
      
      const data = await res.json();
      if (data && data.reply) {
        await addDoc(collection(db, `users/${auth.currentUser.uid}/chat`), {
          role: "assistant",
          content: data.reply,
          timestamp: serverTimestamp()
        });
      } else {
        toast.error("فشل في الحصول على رد من الذكاء الاصطناعي");
      }
    } catch (e) {
      console.error("Chat error:", e);
      toast.error("خطأ في الاتصال بالذكاء الاصطناعي");
    } finally {
      setChatLoading(false);
    }
  };

  const saveTrade = async () => {
    if (!analysis || !auth.currentUser) {
      console.warn("[SaveTrade] No analysis or user found", { analysis: !!analysis, user: !!auth.currentUser });
      return;
    }
    
    const uid = auth.currentUser.uid;
    const tradeId = `${symbol}-${Date.now()}`;
    const capitalRisked = (capital * riskPercent) / 100;

    console.log("[SaveTrade] Starting save...", { symbol, tradeId, capitalRisked });

    try {
      toast.loading("جاري الحفظ...", { id: "save" });

      const userRef = doc(db, `users/${uid}`);
      let userSnap;
      try {
        userSnap = await getDoc(userRef);
      } catch (error) {
        console.error("[SaveTrade] getDoc user error:", error);
        handleFirestoreError(error, OperationType.GET, `users/${uid}`);
      }

      if (!userSnap?.exists()) {
        console.log("[SaveTrade] Creating new user profile in Firestore");
        try {
          await setDoc(userRef, {
            userId: uid,
            capital: capital,
            defaultRiskPercent: riskPercent,
            createdAt: serverTimestamp()
          });
        } catch (error) {
          console.error("[SaveTrade] setDoc user error:", error);
          handleFirestoreError(error, OperationType.CREATE, `users/${uid}`);
        }
      } else {
        console.log("[SaveTrade] Updating existing user profile in Firestore");
        try {
          await setDoc(userRef, {
            capital: capital,
            defaultRiskPercent: riskPercent
          }, { merge: true });
        } catch (error) {
          handleFirestoreError(error, OperationType.UPDATE, `users/${uid}`);
        }
      }

      const tradePath = `users/${uid}/trades/${tradeId}`;
      console.log(`[SaveTrade] Writing trade to path: ${tradePath}`);
      
      try {
        await setDoc(doc(db, tradePath), {
          userId: uid,
          pair: symbol,
          timeframe: timeframe,
          side: analysis.action, // mapping action to side for clarity
          action: analysis.action,
          entry: analysis.entry || 0,
          stopLoss: analysis.stopLoss || 0,
          takeProfit: analysis.takeProfit || 0,
          riskReward: analysis.riskRewardRatio || 0,
          capitalRisked: capitalRisked,
          leverage: leverage,
          psychologicalState: psychState,
          aiDecision: analysis.action,
          aiReasoning: analysis.decisionReason,
          createdAt: serverTimestamp(),
          status: "OPEN",
          trend: analysis.trend || "",
          momentum: analysis.momentum || "",
          score: analysis.tradeScoreOutOf10 || 0,
          entryQuality: analysis.entryQuality || "",
          confidence: analysis.winProbabilityPercent || 0,
          notes: analysis.decisionReason
        });
        console.log("[SaveTrade] Trade written successfully");
        
        // Update trades counter
        setPsychState(prev => ({ ...prev, tradesToday: prev.tradesToday + 1 }));
      } catch (error) {
        console.error("[SaveTrade] setDoc trade error:", error);
        handleFirestoreError(error, OperationType.CREATE, tradePath);
      }
      setTradeSaved(true);
      toast.success("تم حفظ الصفقة بنجاح!", { id: "save" });
    } catch (err: any) {
      console.error("[SaveTrade] Global error:", err);
      const isRulesError = err.message.includes('{') && err.message.includes('authInfo');
      const displayMsg = isRulesError ? "عذراً، لا تملك الصلاحيات الكافية لهذه العملية." : (err.message || "فشل في حفظ الصفقة");
      toast.error(displayMsg, { id: "save" });
    }
  };

  const renderRiskBox = () => {
    if (!analysis || analysis.action === "NO_TRADE") return null;
    
    const entry = analysis.entry;
    const stopLoss = analysis.stopLoss;
    
    if (!entry || !stopLoss) return null;
    
    const maxLoss = capital * (riskPercent / 100);
    const slDistancePct = Math.abs(entry - stopLoss) / entry;
    
    if (slDistancePct === 0) return null;
    
    const positionSize = maxLoss / slDistancePct;
    const margin = positionSize / leverage;
    const quantity = positionSize / entry;
    
    const liquidation = analysis.action === "LONG" 
        ? entry * (1 - (1/leverage)) 
        : entry * (1 + (1/leverage));
        
    const marginWarning = margin > capital;
    const leverageWarning = leverage > 5;
    const tightSlWarning = slDistancePct < 0.0015; // < 0.15%

    return (
      <div className="bg-bg-dark rounded-xl p-4 border border-border-subtle my-4 shadow-sm text-sm space-y-3 relative overflow-hidden">
        <h4 className="font-bold text-xs text-brand-purple mb-2 uppercase tracking-wider">إدارة المخاطر الذكية</h4>
        
        <div className="grid grid-cols-2 gap-3 mb-2">
            <div className="bg-bg-card border border-border-subtle rounded-lg p-2 text-center">
                <div className="text-[10px] text-text-muted mb-0.5">حجم الصفقة الإجمالي</div>
                <div className="font-bold font-mono text-white">${positionSize.toFixed(2)}</div>
            </div>
            <div className="bg-bg-card border border-border-subtle rounded-lg p-2 text-center">
                <div className="text-[10px] text-text-muted mb-0.5">كمية الدخول (Lot)</div>
                <div className="font-bold font-mono text-brand-green">{quantity.toFixed(4)} {symbol.replace('USDT', '')}</div>
            </div>
        </div>

        <div className="flex justify-between items-center text-xs pb-1 border-b border-border-subtle">
           <span className="text-text-muted">أقصى خسارة (Risk):</span>
           <span className="font-mono text-brand-red font-bold">-${maxLoss.toFixed(2)}</span>
        </div>
        <div className="flex justify-between items-center text-xs pb-1 border-b border-border-subtle">
           <span className="text-text-muted">الهامش المطلوب (Margin):</span>
           <span className={`font-mono font-bold ${marginWarning ? 'text-brand-red' : 'text-white'}`}>${margin.toFixed(2)}</span>
        </div>
        <div className="flex justify-between items-center text-xs pb-1 border-b border-border-subtle">
           <span className="text-text-muted">سعر التصفية التقريبي:</span>
           <span className="font-mono text-text-muted">{liquidation.toFixed(2)}</span>
        </div>
        
        <div className="space-y-2 mt-3 text-xs">
          {marginWarning && <div className="text-brand-red font-bold flex items-center gap-1.5 bg-brand-red/10 p-1.5 rounded"><AlertTriangle className="w-3.5 h-3.5" /> حجم الصفقة كبير جداً بالنسبة لرأس مالك</div>}
          {leverageWarning && <div className="text-brand-orange font-bold flex items-center gap-1.5 bg-brand-orange/10 p-1.5 rounded"><AlertTriangle className="w-3.5 h-3.5" /> الرافعة الحالية خطيرة ومجازفة. أقصى يفضل 5x.</div>}
          {tightSlWarning && <div className="text-brand-orange font-bold flex items-center gap-1.5 bg-brand-orange/10 p-1.5 rounded"><AlertTriangle className="w-3.5 h-3.5" /> وقف الخسارة ضيق جداً (عرضة للضرب من ذيول الشموع)</div>}
        </div>
      </div>
    );
  };
  const GeneralSettings = () => (
    <div className="space-y-4 mb-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xs font-bold text-text-muted uppercase tracking-wider flex items-center gap-2">
          وضع التحليل (AI Mode)
          {lastUpdateTime && (
            <span className="text-[10px] text-text-muted/50 font-normal ml-2 flex items-center gap-1" dir="ltr">
               <span className={`w-1.5 h-1.5 rounded-full ${autoUpdate ? 'bg-brand-green animate-pulse' : 'bg-border-subtle'}`}></span>
               {lastUpdateTime.toLocaleTimeString()}
            </span>
          )}
        </h2>
        <div className="flex items-center gap-4">
           <label className="text-xs text-text-muted flex items-center gap-1">
             <input type="checkbox" checked={showIndicators} onChange={(e) => setShowIndicators(e.target.checked)} className="accent-brand-purple" />
             مؤشرات متقدمة
           </label>
           <div className="flex items-center gap-2">
             <label className="text-xs text-text-muted">تحديث تلقائي</label>
             <button 
               onClick={() => setAutoUpdate(!autoUpdate)} 
               className={`w-8 h-4 rounded-full transition-colors relative ${autoUpdate ? 'bg-brand-green' : 'bg-border-subtle'}`}
             >
               <div className={`absolute top-0.5 bottom-0.5 w-3 bg-white rounded-full transition-transform ${autoUpdate ? 'right-0.5 translate-x-0' : 'left-0.5 translate-x-0'}`} style={autoUpdate ? { right: '2px'} : {left: '2px'}} />
             </button>
           </div>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="text-xs text-text-muted mb-1 block">وضع الذكاء الاصطناعي</label>
          <select 
             value={aiMode}
             onChange={(e) => setAiMode(e.target.value)}
             className="w-full bg-bg-dark border border-border-subtle rounded-md px-3 py-2 text-sm focus:outline-none focus:border-brand-purple"
          >
            <option value="Sniper">قناص الصفقات (Sniper)</option>
            <option value="Conservative">تحفظ عالي (Conservative)</option>
            <option value="Aggressive">مضارب سريع (Aggressive)</option>
            <option value="SmartMoney">أموال ذكية (Smart Money)</option>
            <option value="AntiFomo">مدرب صارم (Anti-FOMO)</option>
          </select>
        </div>
        <div>
          <label className="text-xs text-text-muted mb-1 block">تحديث التحليل التلقائي</label>
          <select 
             value={aiAutoAnalysis}
             onChange={(e) => setAiAutoAnalysis(e.target.value)}
             className="w-full bg-bg-dark border border-border-subtle rounded-md px-3 py-2 text-sm focus:outline-none focus:border-brand-purple"
          >
            <option value="On Candle Close">عند إغلاق الشمعة</option>
            <option value="On Strong Signal Only">عند الإشارات القوية فقط</option>
            <option value="Every 5 Minutes">كل 5 دقائق</option>
            <option value="Off">إيقاف (تحديث يدوي)</option>
          </select>
        </div>
      </div>
    </div>
  );

  const RiskSetup = () => (
    <div className="space-y-4">
      <h2 className="text-xs font-bold text-text-muted uppercase tracking-wider hidden md:block">إدارة المخاطر</h2>
      <div className="grid grid-cols-3 md:grid-cols-1 gap-2 text-sm">
        <div>
          <label className="text-text-muted text-[10px] md:text-xs">رأس المال ($)</label>
          <input 
            type="text" 
            inputMode="decimal"
            value={capitalInput} 
            onChange={e => {
              const val = e.target.value.replace(/[^0-9.]/g, '');
              if (val === '' || !isNaN(Number(val))) setCapitalInput(val);
            }} 
            className="w-full bg-bg-dark border border-border-subtle rounded md:px-2 py-2 mt-1 text-center md:text-left text-xs md:text-sm font-mono focus:border-brand-purple outline-none transition-colors" 
            dir="ltr" 
          />
        </div>
        <div>
          <label className="text-text-muted text-[10px] md:text-xs">المخاطرة (%)</label>
          <input 
            type="text" 
            inputMode="decimal"
            value={riskInput} 
            onChange={e => {
              const val = e.target.value.replace(/[^0-9.]/g, '');
              if (val === '' || !isNaN(Number(val))) setRiskInput(val);
            }} 
            className="w-full bg-bg-dark border border-border-subtle rounded md:px-2 py-2 mt-1 text-center md:text-left text-xs md:text-sm font-mono focus:border-brand-purple outline-none transition-colors" 
            dir="ltr" 
          />
        </div>
        <div>
          <label className="text-text-muted text-[10px] md:text-xs">الرافعة (x)</label>
          <input 
            type="text" 
            inputMode="numeric"
            value={leverageInput} 
            onChange={e => {
              const val = e.target.value.replace(/[^0-9]/g, '');
              if (val === '' || !isNaN(Number(val))) setLeverageInput(val);
            }} 
            className="w-full bg-bg-dark border border-border-subtle rounded md:px-2 py-2 mt-1 text-center md:text-left text-xs md:text-sm font-mono focus:border-brand-purple outline-none transition-colors" 
            dir="ltr" 
          />
        </div>
      </div>
      <div className="hidden md:flex flex-col gap-1 text-[11px] text-text-muted mt-2 border-t border-border-subtle pt-2">
         <div className="flex justify-between"><span>المبلغ المخاطر به:</span><span dir="ltr">${((capital * riskPercent) / 100).toFixed(2)}</span></div>
         <div className="flex justify-between"><span>حجم الصفقة (بالرافعة):</span><span dir="ltr">${(((capital * riskPercent) / 100) * leverage).toFixed(2)}</span></div>
      </div>
    </div>
  );

  return (
    <div className="flex flex-col md:flex-row h-full w-full overflow-y-auto md:overflow-hidden bg-bg-dark">
      
      {/* Mobile Top Controls */}
      <div className="md:hidden flex flex-col gap-3 p-4 bg-bg-card border-b border-border-subtle shrink-0 shadow-sm" dir="rtl">
        <div className="flex items-center gap-3 w-full">
           <select 
              value={symbol}
              onChange={(e) => setSymbol(e.target.value)}
              className="bg-bg-dark border border-border-subtle rounded-lg px-3 py-2 text-sm font-bold focus:outline-none focus:border-brand-purple flex-1 shadow-inner h-10"
            >
              <option value="BTCUSDT">BTC/USDT</option>
              <option value="ETHUSDT">ETH/USDT</option>
              <option value="SOLUSDT">SOL/USDT</option>
              <option value="BNBUSDT">BNB/USDT</option>
            </select>
            
            <div className="flex gap-1 flex-1 overflow-x-auto no-scrollbar h-10 items-center bg-bg-dark border border-border-subtle rounded-lg p-1">
              {["1m", "5m", "15m", "1h", "4h"].map(tf => (
                <button
                  key={tf}
                  onClick={() => setTimeframe(tf)}
                  className={`flex-1 py-1 text-xs rounded-md transition-colors ${timeframe === tf ? 'bg-brand-purple text-white shadow-sm font-bold' : 'text-text-muted hover:text-white'}`}
                >
                  {tf}
                </button>
              ))}
            </div>
        </div>
        <GeneralSettings />
        <RiskSetup />
        <NotificationSettings />
        
        <button 
          onClick={handleAnalyze}
          disabled={loading || analyzing || psychTestPassed === false}
          className="w-full py-3 mt-1 text-sm rounded-lg bg-brand-purple/20 border border-brand-purple text-brand-purple hover:bg-brand-purple hover:text-white font-bold tracking-wide transition-all disabled:opacity-50 flex items-center justify-center gap-2"
        >
          {analyzing ? <Activity className="w-5 h-5 animate-pulse" /> : <Bot className="w-5 h-5" />}
          {analyzing ? "جاري التحليل..." : "تحليل السوق AI"}
        </button>
      </div>

      {/* Desktop Left Sidebar */}
      <div className="w-64 border-l border-border-subtle bg-bg-card p-4 gap-6 shrink-0 hidden md:flex flex-col" dir="rtl">
        <div>
          <h2 className="text-xs font-bold text-text-muted uppercase tracking-wider mb-3">اختر السوق</h2>
          <select 
            value={symbol}
            onChange={(e) => setSymbol(e.target.value)}
            className="w-full bg-bg-dark border border-border-subtle rounded-md px-3 py-2 text-sm focus:outline-none focus:border-brand-purple"
          >
            <option value="BTCUSDT">BTC/USDT</option>
            <option value="ETHUSDT">ETH/USDT</option>
             <option value="SOLUSDT">SOL/USDT</option>
             <option value="BNBUSDT">BNB/USDT</option>
          </select>
        </div>

        <div>
          <h2 className="text-xs font-bold text-text-muted uppercase tracking-wider mb-3">الإطار الزمني</h2>
          <div className="flex gap-2">
            {["1m", "5m", "15m", "1h", "4h"].map(tf => (
              <button
                key={tf}
                onClick={() => setTimeframe(tf)}
                className={`flex-1 py-1 text-xs rounded transition-colors ${timeframe === tf ? 'bg-brand-purple text-white relative shadow-[0_0_10px_rgba(124,77,255,0.5)]' : 'bg-bg-dark text-text-muted hover:bg-border-subtle'}`}
              >
                {tf}
                {timeframe === tf && <motion.div layoutId="tf-indicator" className="absolute inset-0 rounded border border-brand-purple/50 bg-transparent" />}
              </button>
            ))}
          </div>
        </div>

        <GeneralSettings />
        <RiskSetup />
        <NotificationSettings />

        <button 
          onClick={handleAnalyze}
          disabled={loading || analyzing || psychTestPassed === false}
          className="mt-auto w-full py-3 rounded-lg bg-brand-purple hover:bg-opacity-90 font-semibold text-white tracking-wide transition-all disabled:opacity-50 flex items-center justify-center gap-2 relative overflow-hidden"
        >
          {analyzing && <motion.div initial={{ x: -100 }} animate={{ x: 300 }} transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }} className="absolute inset-0 bg-white/20 skew-x-12 w-12" />}
          {analyzing ? <Activity className="w-5 h-5 animate-pulse" /> : <Bot className="w-5 h-5" />}
          {analyzing ? "جاري التحليل المعمق..." : "تحليل الذكاء الاصطناعي"}
        </button>
      </div>

      {/* Main Chart Column */}
      <div className="flex-1 flex flex-col p-2 md:p-4 min-h-[400px] md:min-h-0 w-full relative">
        {/* Connection Status Indicators */}
        <div className="flex items-center gap-4 mb-2 px-1 overflow-x-auto no-scrollbar whitespace-nowrap">
          <div className="flex items-center gap-1.5 px-2 py-1 bg-bg-card border border-border-subtle rounded-full text-[10px] font-bold">
            <div className={`w-1.5 h-1.5 rounded-full ${candles.length > 0 ? 'bg-brand-green' : 'bg-brand-red animate-pulse'}`} />
            <span className="text-text-muted">السوق:</span>
            <span className={candles.length > 0 ? 'text-brand-green' : 'text-brand-red'}>{candles.length > 0 ? 'متصل' : 'مقطوع'}</span>
          </div>
          <div className="flex items-center gap-1.5 px-2 py-1 bg-bg-card border border-border-subtle rounded-full text-[10px] font-bold">
            <div className={`w-1.5 h-1.5 rounded-full ${analyzing ? 'bg-brand-purple animate-pulse' : 'bg-brand-green'}`} />
            <span className="text-text-muted">الذكاء الاصطناعي:</span>
            <span className="text-brand-purple">{aiMode}</span>
          </div>
        </div>

        <div className="flex-1 bg-bg-card md:rounded-xl border border-border-subtle overflow-hidden relative shadow-lg min-h-[350px]">
          {candles.length > 0 ? (
            <div className="w-full h-[100%] absolute inset-0 group" dir="ltr">
               <Chart data={candles} />
               
               {/* Advanced Indicators Widget */}
               {showIndicators && (
                  <div className="absolute top-4 left-4 z-10 hidden md:flex flex-col gap-1 text-xs opacity-50 group-hover:opacity-100 transition-opacity bg-bg-dark/80 backdrop-blur-sm p-3 rounded-lg border border-border-subtle" dir="rtl">
                    <div className="flex justify-between items-center w-40">
                      <span className="font-bold text-text-muted">EMA (200):</span>
                      <span className="font-mono">{candles[candles.length - 1]?.ema200?.toFixed(2) || '---'}</span>
                    </div>
                    <div className="flex justify-between items-center w-40">
                      <span className="font-bold text-text-muted">MACD:</span>
                      <span className="font-mono">{candles[candles.length - 1]?.macd?.MACD?.toFixed(2) || '---'}</span>
                    </div>
                    <div className="flex justify-between items-center w-40">
                      <span className="font-bold text-text-muted">ATR (14):</span>
                      <span className="font-mono">{candles[candles.length - 1]?.atr?.toFixed(2) || '---'}</span>
                    </div>
                    <div className="flex justify-between items-center w-40">
                      <span className="font-bold text-text-muted">Vol Delta:</span>
                      <span className={`font-mono ${(candles[candles.length - 1]?.volumeDelta || 0) >= 0 ? 'text-brand-green' : 'text-brand-red'}`}>
                        {(candles[candles.length - 1]?.volumeDelta || 0) > 0 ? '+' : ''}{candles[candles.length - 1]?.volumeDelta?.toFixed(2) || '---'}
                      </span>
                    </div>
                  </div>
               )}
            </div>
          ) : (
            <div className="w-full h-full p-8 flex flex-col gap-4">
              <div className="w-full h-full bg-bg-dark/50 animate-pulse rounded-lg flex items-center justify-center">
                 <div className="flex flex-col items-center gap-3">
                   <Activity className="w-10 h-10 text-brand-purple animate-spin" />
                   <span className="text-sm font-medium text-text-muted">جاري تحميل بيانات السوق الحية...</span>
                 </div>
              </div>
            </div>
          )}
          
          <button 
            onClick={() => setChatOpen(!chatOpen)}
            className="absolute bottom-4 right-4 bg-brand-purple text-white p-3 md:p-4 rounded-full shadow-[0_0_15px_rgba(124,77,255,0.5)] hover:bg-opacity-90 transition-all z-20 hover:scale-105 active:scale-95 flex items-center justify-center"
          >
            {chatOpen ? <span className="text-xl font-bold px-1">&times;</span> : <MessageSquare className="w-5 h-5 md:w-6 md:h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile/Desktop Output AI Section */}
      <div className={`w-full md:w-80 border-t md:border-t-0 md:border-r border-border-subtle bg-bg-card flex flex-col shrink-0 transition-all duration-300 ease-in-out ${chatOpen ? 'h-[60vh] md:h-auto md:w-96 shadow-2xl relative' : ''}`} dir="rtl">
        {!chatOpen ? (
          <div className="p-4 flex-1 overflow-y-auto w-full md:w-80 h-full">
            <h2 className="text-base md:text-sm font-bold uppercase tracking-wider mb-6 md:mb-4 flex items-center gap-2">
              <Bot className="w-5 h-5 text-brand-purple" /> قرار التداول الذكي
            </h2>
            
            {psychTestPassed === false && (
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-brand-red/10 border border-brand-red/30 rounded-lg p-4 mb-4">
                <div className="flex items-center gap-2 text-brand-red font-bold mb-2">
                  <AlertTriangle className="w-4 h-4" /> 
                  أنت غير مؤهل نفسيًا للتداول
                </div>
                <p className="text-xs text-text-muted mb-3">توتر أو تسرع. خذ استراحة لحماية رأس مالك.</p>
                <button onClick={() => setPsychTestPassed(null)} className="w-full py-2 bg-bg-dark rounded text-xs text-brand-purple hover:bg-border-subtle transition-colors">أعد التقييم لاحقاً</button>
              </motion.div>
            )}

            <div className="relative min-h-[300px]">
              <AnimatePresence mode="wait">
                {analysis ? (
                  <motion.div key="result" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-4 pb-10 md:pb-4 relative">
                    
                    {analyzing && (
                      <div className="absolute inset-0 z-10 bg-bg-dark/60 backdrop-blur-sm rounded-xl flex flex-col items-center justify-center">
                        <div className="w-12 h-12 rounded-full border-4 border-border-subtle border-t-brand-purple animate-spin"></div>
                        <p className="text-brand-purple text-sm mt-4 font-bold animate-pulse">جاري تحديث التحليل...</p>
                      </div>
                    )}

                    {/* Action UI */}
                    <div className={`p-5 md:p-4 rounded-xl border relative shadow-inner flex flex-col items-center justify-center ${
                      analysis.action === "LONG" ? "border-brand-green/50 bg-brand-green/10" :
                      analysis.action === "SHORT" ? "border-brand-red/50 bg-brand-red/10" :
                      "border-text-muted/50 bg-text-muted/10"
                    }`}>
                        <div className="text-center font-black text-3xl md:text-2xl tracking-widest mb-1 drop-shadow-md" style={{
                          color: analysis.action === "LONG" ? "var(--color-brand-green)" : analysis.action === "SHORT" ? "var(--color-brand-red)" : "var(--color-text-muted)"
                        }}>
                          {analysis.action}
                        </div>
  
                        <div className="absolute top-3 right-3 md:top-2 md:right-2 flex items-center justify-center w-8 h-8 rounded-full bg-bg-dark border border-border-subtle font-bold text-xs shadow-sm" title="تقييم الفرصة من 10">
                           {analysis.tradeScoreOutOf10}/10
                        </div>
                    </div>

                  {/* Indicator Grid */}
                  <div className="grid grid-cols-2 lg:grid-cols-2 gap-2 text-center text-xs">
                    <div className="bg-bg-dark p-3 md:p-2 rounded-lg border border-border-subtle flex flex-col items-center justify-center shadow-sm">
                      <span className="text-text-muted mb-1 font-medium">صلاحية التداول</span>
                      <span className={`font-bold ${analysis.isTradable ? 'text-brand-green' : 'text-brand-red'} text-sm`}>
                        {analysis.isTradable ? 'سوق مناسب' : 'غير متداول'}
                      </span>
                    </div>
                    <div className="bg-bg-dark p-3 md:p-2 rounded-lg border border-border-subtle flex flex-col items-center justify-center shadow-sm">
                      <span className="text-text-muted mb-1 font-medium">احتمالية النجاح</span>
                      <span className="font-mono text-sm font-bold" style={{ color: `hsl(${analysis.winProbabilityPercent * 1.2}, 100%, 50%)` }}>
                        {analysis.winProbabilityPercent ? `${analysis.winProbabilityPercent}%` : '-'}
                      </span>
                    </div>
                    <div className="bg-bg-dark p-3 md:p-2 rounded-lg border border-border-subtle flex flex-col items-center justify-center shadow-sm">
                      <span className="text-text-muted mb-1 font-medium">الاتجاه العام</span>
                      <span className="font-bold text-sm">{analysis.trend}</span>
                    </div>
                    <div className="bg-bg-dark p-3 md:p-2 rounded-lg border border-border-subtle flex flex-col items-center justify-center shadow-sm">
                      <span className="text-text-muted mb-1 font-medium">الزخم (Momentum)</span>
                      <span className="font-bold text-sm">{analysis.momentum}</span>
                    </div>
                  </div>

                  {/* Trade Setup details */}
                  {analysis.action !== "NO_TRADE" && (
                      <div className="bg-bg-dark rounded-xl p-5 md:p-4 border border-border-subtle text-sm space-y-3 relative overflow-hidden shadow-sm">
                        <div className="flex justify-between items-center pb-2 border-b border-border-subtle">
                          <span className="text-text-muted font-bold">نقطة الدخول</span>
                          <span className="font-mono text-white tracking-wider" dir="ltr">{analysis.entry}</span>
                        </div>
                        <div className="flex justify-between items-center pb-2 border-b border-border-subtle">
                          <span className="text-text-muted font-bold flex items-center gap-1"><TrendingUp className="w-4 h-4 text-brand-green" /> الهدف</span>
                          <span className="font-mono text-brand-green tracking-wider" dir="ltr">{analysis.takeProfit}</span>
                        </div>
                        <div className="flex justify-between items-center pb-2 border-b border-border-subtle">
                          <span className="text-text-muted font-bold flex items-center gap-1"><Crosshair className="w-4 h-4 text-brand-red" /> وقف الخسارة</span>
                          <span className="font-mono text-brand-red tracking-wider" dir="ltr">{analysis.stopLoss}</span>
                        </div>
                        {analysis.entryQuality && (
                          <div className="flex justify-between items-center pt-1">
                            <span className="text-text-muted font-bold text-xs">جودة الدخول:</span>
                            <span className={`text-xs font-bold px-2 py-0.5 rounded ${
                                analysis.entryQuality.includes('Excellent') ? 'bg-brand-green/20 text-brand-green' :
                                analysis.entryQuality.includes('Good') ? 'bg-brand-purple/20 text-brand-purple' :
                                analysis.entryQuality.includes('Late') ? 'bg-brand-orange/20 text-brand-orange' :
                                'bg-brand-red/20 text-brand-red'
                            }`}>{analysis.entryQuality}</span>
                          </div>
                        )}
                      </div>
                  )}

                  {/* Render Calculated Risk Management Box */}
                  {renderRiskBox()}

                  {/* Smart Warnings */}
                  {(analysis.lateEntryWarning || analysis.badRiskRewardWarning || analysis.fakeBreakoutWarning) && (
                    <div className="space-y-2 mb-4">
                      {analysis.lateEntryWarning && (
                        <div className="bg-brand-orange/10 border border-brand-orange/30 rounded-lg p-3 text-xs md:text-sm flex items-start gap-3 shadow-inner">
                           <AlertTriangle className="w-5 h-5 text-brand-orange shrink-0 mt-0.5" />
                           <span className="text-brand-orange font-bold leading-relaxed">Late Entry Warning:<br/><span className="text-text-main font-normal block mt-1">السعر تحرك بعيدًا عن أفضل نقطة دخول. انتبه.</span></span>
                        </div>
                      )}
                      {analysis.badRiskRewardWarning && (
                        <div className="bg-brand-red/10 border border-brand-red/30 rounded-lg p-3 text-xs md:text-sm flex items-start gap-3 shadow-inner">
                           <AlertTriangle className="w-5 h-5 text-brand-red shrink-0 mt-0.5" />
                           <span className="text-brand-red font-bold leading-relaxed">تحذير المخاطرة:<br/><span className="text-text-main font-normal block mt-1">نسبة العائد للمخاطرة سيئة جداً.</span></span>
                        </div>
                      )}
                      {analysis.fakeBreakoutWarning && (
                        <div className="bg-brand-purple/10 border border-brand-purple/30 rounded-lg p-3 text-xs md:text-sm flex items-start gap-3 shadow-inner">
                           <AlertTriangle className="w-5 h-5 text-brand-purple shrink-0 mt-0.5" />
                           <span className="text-brand-purple font-bold leading-relaxed">تحذير كسر وهمي:<br/><span className="text-text-main font-normal block mt-1">{analysis.fakeBreakoutWarning}</span></span>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Short Reasons List */}
                  {analysis.shortEntryReasons && analysis.shortEntryReasons.length > 0 && (
                    <div className="bg-bg-dark rounded-xl p-4 md:p-3 border border-border-subtle text-sm relative shadow-sm">
                      <div className="absolute top-0 right-0 w-1 h-full bg-brand-green rounded-r-xl"></div>
                      <h4 className="text-xs md:text-[11px] font-bold text-text-muted mb-3 mr-2 uppercase tracking-wider">سبب الدخول المختصر:</h4>
                      <ul className="text-text-main mr-4 leading-relaxed list-disc marker:text-brand-purple space-y-1.5 font-medium" dir="rtl">
                        {analysis.shortEntryReasons.map((r, i) => (
                          <li key={i}>{r}</li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Market Structure */}
                  {analysis.marketStructureAnalysis && (
                    <div className="bg-bg-dark rounded-xl p-4 md:p-3 border border-border-subtle text-sm relative shadow-sm">
                      <div className="absolute top-0 right-0 w-1 h-full bg-blue-500 rounded-r-xl"></div>
                      <h4 className="text-xs md:text-[11px] font-bold text-blue-400 mb-2 mr-2 uppercase tracking-wider">هيكل السوق (Market Structure):</h4>
                      <p className="text-text-main mr-2 leading-relaxed" dir="rtl">
                        {analysis.marketStructureAnalysis}
                      </p>
                    </div>
                  )}

                  {/* detailed Reasoning */}
                  <div className="bg-bg-dark rounded-xl p-4 md:p-3 border border-border-subtle text-sm relative shadow-sm">
                    <div className="absolute top-0 right-0 w-1 h-full bg-brand-purple rounded-r-xl"></div>
                    <h4 className="text-xs md:text-[11px] font-bold text-text-muted mb-2 mr-2 uppercase tracking-wider">التحليل المعمق:</h4>
                    <p className="text-text-main mr-2 leading-relaxed opacity-90" dir="rtl">
                      {analysis.decisionReason}
                    </p>
                  </div>
                  
                  <button 
                    onClick={saveTrade}
                    disabled={tradeSaved || analysis.action === "NO_TRADE"}
                    className="w-full py-4 md:py-3 mt-4 rounded-xl border-2 border-brand-purple text-brand-purple hover:bg-brand-purple hover:text-white flex flex-row items-center justify-center gap-2 transition-all disabled:opacity-50 disabled:hover:bg-transparent disabled:hover:text-brand-purple font-bold"
                  >
                    {tradeSaved ? <CheckCircle className="w-5 h-5" /> : <Save className="w-5 h-5" />}
                    {tradeSaved ? "تم الحفظ بالسجل" : "احفظ الصفقة في السجل"}
                  </button>

                  <div className="flex flex-col items-center gap-2 mt-4">
                    {lastAnalysisTime && (
                      <span className="text-[10px] text-text-muted">
                        آخر تحليل تم عند: {lastAnalysisTime.toLocaleTimeString()}
                      </span>
                    )}
                    <button 
                      onClick={() => triggerAiAnalysis(candles)}
                      disabled={analyzing}
                      className="text-xs text-brand-purple hover:text-white transition-colors underline decoration-brand-purple/50 decoration-dashed underline-offset-4"
                    >
                      تحديث التحليل الآن
                    </button>
                  </div>
                </motion.div>
              ) : analyzing ? (
                <motion.div key="loading" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col items-center justify-center p-10 space-y-4 min-h-[250px]">
                   <div className="w-16 h-16 rounded-full border-4 border-border-subtle border-t-brand-purple animate-spin"></div>
                   <p className="text-brand-purple text-sm font-medium animate-pulse text-center">جاري التحليل المعمق واستخراج بيانات الهيكل السعري...</p>
                </motion.div>
              ) : (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col items-center justify-center flex-1 text-center opacity-40 h-full min-h-[300px]">
                  <Bot className="w-16 h-16 mb-4 drop-shadow-lg" />
                  <p className="text-sm px-6 leading-relaxed font-medium">المنصة في وضع المراقبة.<br/>قم بالاختيار ثم أنقر على "تحليل" للحصول على قراءة فنية متكاملة.</p>
                </motion.div>
              )}
              </AnimatePresence>
            </div>
          </div>
        ) : (
          <div className="flex flex-col h-[85vh] md:h-full bg-bg-dark md:border-r border-border-subtle w-full md:w-96 fixed md:static inset-0 z-50 md:z-auto">
            <div className="p-4 border-b border-border-subtle flex justify-between items-center bg-bg-card shrink-0 shadow-sm pt-safe-top">
               <h3 className="font-bold flex items-center gap-2"><MessageSquare className="w-5 h-5 text-brand-purple"/> محادثة الكوتش الحصرية</h3>
               <button onClick={() => setChatOpen(false)} className="text-text-muted hover:text-white p-2 rounded-full hover:bg-border-subtle transition">&times;</button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {chatHistory.length === 0 && (
                <div className="text-center text-text-muted text-sm mt-10 space-y-4">
                  <Bot className="w-12 h-12 mx-auto opacity-50" />
                  <p className="leading-relaxed">اسأل الكوتش أي سؤال عن السوق، التحليل، أو حالتك النفسية وسيراجع سجلك أيضاً.</p>
                  <p className="mt-4 text-xs opacity-70 border border-border-subtle p-3 rounded-lg cursor-pointer hover:border-brand-purple transition-colors bg-bg-dark font-medium" onClick={() => setChatMessage("إيه رأيك في صفقات اليوم؟")}>"إيه رأيك في صفقات اليوم؟"</p>
                </div>
              )}
              {chatHistory.map((msg, idx) => (
                <div key={idx} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
                  <div className={`max-w-[85%] rounded-2xl p-4 text-sm leading-relaxed ${
                    msg.role === "user" ? "bg-brand-purple text-white shadow-md shadow-brand-purple/20 rounded-tl-sm" : "bg-bg-card border border-border-subtle text-text-main shadow-md rounded-tr-sm"
                  }`} dir="rtl">
                    {msg.content}
                  </div>
                </div>
              ))}
              {chatLoading && (
                <div className="flex justify-start">
                   <div className="bg-bg-card border border-border-subtle rounded-2xl rounded-tr-sm p-4 text-sm text-text-muted flex gap-2 items-center shadow-sm">
                     <span className="w-2 h-2 bg-brand-purple rounded-full animate-bounce"></span>
                     <span className="w-2 h-2 bg-brand-purple rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
                     <span className="w-2 h-2 bg-brand-purple rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
                   </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>

            <div className={`p-3 bg-bg-card border-t border-border-subtle shrink-0 pb-safe ${chatLoading ? 'opacity-50 pointer-events-none' : ''}`}>
               <form onSubmit={e => { e.preventDefault(); if(!chatLoading && chatMessage.trim()) sendChatMessage(); }} className="flex gap-2 relative">
                <input 
                  autoFocus
                  disabled={chatLoading}
                  value={chatMessage}
                  onChange={e => setChatMessage(e.target.value)}
                  placeholder="اكتب رسالة للكوتش..."
                  className="flex-1 bg-bg-dark border border-border-subtle rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-brand-purple transition-colors pr-12 shadow-inner"
                  dir="rtl"
                />
                <button type="submit" disabled={chatLoading || !chatMessage.trim()} className="absolute left-2 top-2 bottom-2 bg-brand-purple text-white px-3 rounded-lg hover:bg-opacity-90 disabled:opacity-50 transition-colors shadow-sm flex items-center justify-center">
                  {chatLoading ? (
                    <div className="w-4 h-4 rounded-full border-2 border-white/30 border-t-white animate-spin"></div>
                  ) : (
                    <Send className="w-4 h-4" style={{ transform: "rotate(180deg)" }} />
                  )}
                </button>
              </form>
            </div>
          </div>
        )}
      </div>

      {/* Psychology Pre-test Modal */}
      <AnimatePresence>
      {psychOpen && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="fixed inset-0 bg-black/80 backdrop-blur-md z-[100] flex items-center justify-center p-4">
          <motion.div initial={{ scale: 0.95, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }} exit={{ scale: 0.95, opacity: 0, y: 20 }} className="bg-bg-card border border-border-subtle rounded-3xl w-full max-w-[450px] p-6 md:p-8 shadow-[0_0_50px_rgba(124,77,255,0.2)] relative max-h-[90vh] overflow-y-auto">
             <button onClick={() => setPsychOpen(false)} className="absolute top-4 right-4 text-text-muted hover:text-white w-8 h-8 flex items-center justify-center rounded-full hover:bg-border-subtle transition-colors mb-4 md:mb-0 z-10">&times;</button>
            <h2 className="text-lg md:text-xl font-bold mb-6 mt-4 md:mt-0 text-center text-white flex justify-center items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-brand-purple/20 flex items-center justify-center shrink-0">
                <Activity className="text-brand-purple w-5 h-5" />
              </div>
              التقييم النفسي قبل التداول
            </h2>
            
            <div className="space-y-4 md:space-y-5 mb-8" dir="rtl">
              <div className="bg-bg-dark p-5 rounded-2xl border border-border-subtle shadow-inner">
                <label className="block text-sm font-medium mb-4 text-white flex justify-between items-center">حالتك النفسية الحالية من 10؟ <span className="text-brand-purple font-black text-2xl">{psychState.scoreOutOf10}</span></label>
                <input type="range" min="1" max="10" value={psychState.scoreOutOf10} onChange={e => setPsychState({...psychState, scoreOutOf10: Number(e.target.value)})} className="w-full accent-brand-purple h-2 rounded-lg appearance-none bg-border-subtle" />
                <div className="flex justify-between text-xs text-text-muted mt-3 px-1 font-medium"><span>سيء ومدمر</span><span>ممتاز وحاضر</span></div>
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                  <label className={`flex flex-col items-center justify-center gap-3 p-5 rounded-2xl border-2 cursor-pointer transition-all ${psychState.stressed ? 'border-brand-red bg-brand-red/10 text-brand-red shadow-[0_0_15px_rgba(255,59,48,0.15)]' : 'border-border-subtle bg-bg-dark text-text-muted hover:text-white hover:border-text-muted'}`}>
                    <input type="checkbox" checked={psychState.stressed} onChange={e => setPsychState({...psychState, stressed: e.target.checked})} className="hidden" />
                    <AlertTriangle className="w-6 h-6" />
                    <span className="text-xs font-bold text-center">أشعر بالتوتر <br/>أو الضغط</span>
                  </label>

                  <label className={`flex flex-col items-center justify-center gap-3 p-5 rounded-2xl border-2 cursor-pointer transition-all ${psychState.revengeTrading ? 'border-brand-red bg-brand-red/10 text-brand-red shadow-[0_0_15px_rgba(255,59,48,0.15)]' : 'border-border-subtle bg-bg-dark text-text-muted hover:text-white hover:border-text-muted'}`}>
                    <input type="checkbox" checked={psychState.revengeTrading} onChange={e => setPsychState({...psychState, revengeTrading: e.target.checked})} className="hidden" />
                    <Crosshair className="w-6 h-6" />
                    <span className="text-xs font-bold text-center">أريد الانتقام <br/>من السوق</span>
                  </label>

                  <label className={`flex flex-col items-center justify-center gap-3 p-5 rounded-2xl border-2 cursor-pointer transition-all ${psychState.fomo ? 'border-brand-orange bg-brand-orange/10 text-brand-orange shadow-[0_0_15px_rgba(255,149,0,0.15)]' : 'border-border-subtle bg-bg-dark text-text-muted hover:text-white hover:border-text-muted'}`}>
                    <input type="checkbox" checked={psychState.fomo} onChange={e => setPsychState({...psychState, fomo: e.target.checked})} className="hidden" />
                    <Activity className="w-6 h-6" />
                    <span className="text-xs font-bold text-center">أخاف تفوتني <br/> فرصة (FOMO)</span>
                  </label>

                   <label className={`flex flex-col items-center justify-center gap-3 p-5 rounded-2xl border-2 cursor-pointer transition-all ${psychState.wellRested ? 'border-brand-green bg-brand-green/10 text-brand-green shadow-[0_0_15px_rgba(52,199,89,0.15)]' : 'border-border-subtle bg-bg-dark text-text-muted hover:text-white hover:border-text-muted'}`}>
                    <input type="checkbox" checked={psychState.wellRested} onChange={e => setPsychState({...psychState, wellRested: e.target.checked})} className="hidden" />
                    <CheckCircle className="w-6 h-6" />
                    <span className="text-xs font-bold text-center">مسترخي وفي <br/> كامل تركيزي</span>
                  </label>
              </div>

              <div className="bg-bg-dark p-5 rounded-2xl border border-border-subtle flex items-center justify-between shadow-inner">
                <label className="text-sm font-bold text-white">عدد الصفقات المنفذة اليوم؟</label>
                <input type="number" min="0" max="50" value={psychState.tradesToday} onChange={e => setPsychState({...psychState, tradesToday: Number(e.target.value)})} className="w-20 bg-bg-card border-2 border-border-subtle rounded-xl px-3 py-2 text-white text-center font-black text-lg outline-none focus:border-brand-purple transition-colors shadow-sm" />
              </div>
            </div>

            <button onClick={submitPsychTest} className="w-full py-4 bg-brand-purple text-white font-black rounded-2xl hover:bg-opacity-90 transition-all shadow-[0_4px_20px_rgba(124,77,255,0.4)] flex items-center justify-center gap-3 text-lg hover:scale-[1.02] active:scale-[0.98]">
              <Bot className="w-6 h-6" />
              دخول المنصة للتحليل
            </button>
          </motion.div>
        </motion.div>
      )}
      </AnimatePresence>
    </div>
  );
}
