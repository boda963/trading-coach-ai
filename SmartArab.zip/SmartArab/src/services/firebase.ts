import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';
import { handleFirestoreError, OperationType } from "../lib/firestoreErrorHandler";
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);

// Test the connection as instructed by guidelines
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if(error instanceof Error && error.message.includes('the client is offline')) {
      console.error("Please check your Firebase configuration.");
    } else {
      try {
        handleFirestoreError(error, OperationType.GET, 'test/connection');
      } catch (e) {
        // Just log the formatted error
        console.warn("Firestore Connection Test failed (Expected if rules haven't propagated):", e);
      }
    }
  }
}
testConnection();
