/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter, Routes, Route, Link, useLocation } from "react-router-dom";
import { useEffect, useState } from "react";
import { signInWithPopup, GoogleAuthProvider, signOut } from "firebase/auth";
import { auth } from "./services/firebase";
import TradingDashboard from "./components/TradingDashboard";
import DashboardOverview from "./components/DashboardOverview";
import Journal from "./components/Journal";
import { Toaster } from "react-hot-toast";
import NotificationManager from "./components/NotificationManager";
import ScannerDaemon from "./components/ScannerDaemon";

import { Target, BarChart2, BookOpen } from "lucide-react";

function Navigation() {
  const location = useLocation();
  const [user, setUser] = useState(auth.currentUser);

  useEffect(() => {
    const unsub = auth.onAuthStateChanged((u) => setUser(u));
    return unsub;
  }, []);

  const login = () => signInWithPopup(auth, new GoogleAuthProvider());
  const logout = () => signOut(auth);

  return (
    <>
      <header className="h-14 border-b border-border-subtle flex items-center px-4 md:px-6 justify-between bg-bg-card shrink-0 gap-4" dir="rtl">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-brand-purple flex items-center justify-center font-bold text-white tracking-widest text-xs">
            TC
          </div>
          <h1 className="font-bold tracking-tight text-white text-sm md:text-base">تريدينج كوتش AI</h1>
        </div>
        <nav className="hidden md:flex gap-6 flex-1 pr-10 items-center text-sm font-medium">
          <Link to="/" className={`transition-colors py-4 border-b-2 ${location.pathname === '/' ? 'border-brand-purple text-brand-purple' : 'border-transparent text-text-muted hover:text-text-main'}`}>منصة التداول</Link>
          <Link to="/dashboard" className={`transition-colors py-4 border-b-2 ${location.pathname === '/dashboard' ? 'border-brand-purple text-brand-purple' : 'border-transparent text-text-muted hover:text-text-main'}`}>لوحة التحكم</Link>
          <Link to="/journal" className={`transition-colors py-4 border-b-2 ${location.pathname === '/journal' ? 'border-brand-purple text-brand-purple' : 'border-transparent text-text-muted hover:text-text-main'}`}>السجل</Link>
        </nav>
        <div>
          {user ? (
            <button onClick={logout} className="text-xs bg-bg-dark border border-border-subtle px-3 py-1.5 md:px-4 md:py-2 rounded-lg hover:bg-border-subtle text-white font-medium transition-colors">خروج</button>
          ) : (
            <button onClick={login} className="text-xs bg-brand-purple px-3 py-1.5 md:px-4 md:py-2 rounded-lg hover:bg-opacity-90 text-white font-medium transition-colors shadow-sm shadow-brand-purple/20">الدخول بجوجل</button>
          )}
        </div>
      </header>

      {user && (
        <div className="md:hidden fixed bottom-0 left-0 right-0 h-16 bg-bg-card border-t border-border-subtle flex items-center justify-around px-2 z-50 pb-safe" dir="rtl">
          <Link to="/" className={`flex flex-col items-center justify-center w-full h-full gap-1 transition-colors ${location.pathname === '/' ? 'text-brand-purple' : 'text-text-muted'}`}>
             <BarChart2 className="w-5 h-5" />
             <span className="text-[10px] font-medium">المنصة</span>
          </Link>
          <Link to="/dashboard" className={`flex flex-col items-center justify-center w-full h-full gap-1 transition-colors ${location.pathname === '/dashboard' ? 'text-brand-purple' : 'text-text-muted'}`}>
             <Target className="w-5 h-5" />
             <span className="text-[10px] font-medium">اللوحة</span>
          </Link>
          <Link to="/journal" className={`flex flex-col items-center justify-center w-full h-full gap-1 transition-colors ${location.pathname === '/journal' ? 'text-brand-purple' : 'text-text-muted'}`}>
             <BookOpen className="w-5 h-5" />
             <span className="text-[10px] font-medium">السجل</span>
          </Link>
        </div>
      )}
    </>
  );
}

export default function App() {
  const [user, setUser] = useState(auth.currentUser);

  useEffect(() => {
    const unsub = auth.onAuthStateChanged((u) => setUser(u));
    return unsub;
  }, []);

  return (
    <BrowserRouter>
      <div className="w-full min-h-screen bg-bg-dark text-text-main flex flex-col font-sans">
        <Toaster position="top-center" toastOptions={{ className: 'bg-bg-card text-white border border-border-subtle shadow-xl', style: { padding: '16px 20px', borderRadius: '12px' } }} />
        <NotificationManager />
        <ScannerDaemon />
        
        <Navigation />

        <main className="flex-1 overflow-hidden flex flex-col pb-16 md:pb-0">
          {user ? (
             <Routes>
               <Route path="/" element={<TradingDashboard />} />
               <Route path="/dashboard" element={<DashboardOverview />} />
               <Route path="/journal" element={<Journal />} />
             </Routes>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center bg-bg-dark p-6" dir="rtl">
              <div className="w-20 h-20 bg-brand-purple/20 rounded-2xl flex items-center justify-center mb-8 border border-brand-purple/30">
                 <span className="text-3xl font-black text-brand-purple">TC</span>
              </div>
              <h2 className="text-3xl font-bold mb-4 text-white">تريدينج كوتش AI</h2>
              <p className="text-text-muted mb-8 max-w-md text-center leading-relaxed">
                مساعد التداول الذكي الذي يحلل السوق نيابة عنك ويحميك من القرارات العاطفية والمتهورة. 
                قم بتسجيل الدخول لبدء التداول بشكل احترافي.
              </p>
              <button onClick={() => signInWithPopup(auth, new GoogleAuthProvider())} className="bg-brand-purple text-white px-8 py-4 rounded-xl font-bold hover:bg-opacity-90 transition-all shadow-lg shadow-brand-purple/30 flex items-center gap-2">
                تسجيل الدخول باستخدام جوجل للبدء
              </button>
            </div>
          )}
        </main>
      </div>
    </BrowserRouter>
  );
}
