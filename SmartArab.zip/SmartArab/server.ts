import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import { SMA, RSI, ATR, EMA, MACD } from "technicalindicators";

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

const GEMINI_MODEL = "gemini-flash-latest";
const FALLBACK_MODELS = [
  "gemini-flash-latest",
  "gemini-flash-lite-latest",
  "gemini-2.0-flash", // Adjusted to supported naming if needed, but keeping user preference
  "gemini-1.5-flash"
];

async function callGeminiWithFallback(options: { contents: any, config?: any, isJson?: boolean }) {
  let lastError = null;
  
  for (const modelName of FALLBACK_MODELS) {
    try {
      console.log(`[Gemini] Current Model: ${modelName}`);
      
      const response = await ai.models.generateContent({
        model: modelName,
        contents: options.contents,
        config: options.config
      });
      
      console.log(`[Gemini] Gemini Connected - Response Received from ${modelName}`);
      return response;
    } catch (error: any) {
      lastError = error;
      const errString = String(error) + (error.message || "");
      console.error(`[Gemini] Gemini Failed on ${modelName}:`, errString);
      
      if (modelName !== FALLBACK_MODELS[FALLBACK_MODELS.length - 1]) {
        console.log(`[Gemini] Trying Fallback...`);
      }
    }
  }
  
  throw lastError;
}

const getMockAnalysis = (params: any, lastCandle: any) => {
  return {
    action: "NO_TRADE",
    decisionReason: "تعذر الاتصال بالذكاء الاصطناعي، تم استخدام تحليل احتياطي بناءً على المؤشرات الفنية المتاحة.",
    trend: lastCandle.close > lastCandle.sma50 ? "صاعد" : "هابط",
    momentum: lastCandle.rsi > 60 ? "قوي" : lastCandle.rsi < 40 ? "ضعيف" : "متوسط",
    isTradable: false,
    tradeScoreOutOf10: 5,
    currentRsi: lastCandle.rsi,
    shortEntryReasons: ["تحليل احتياطي", "فشل الاتصال بـ AI"],
    marketStructureAnalysis: "النظام في وضع الاحتياط. المؤشرات تشير إلى وضع غير مستقر.",
    lateEntryWarning: false,
    badRiskRewardWarning: true,
    fakeBreakoutWarning: "لا يمكن تأكيد الاختراقات الكاذبة في وضع الاحتياط.",
    winProbabilityPercent: 50,
    entryQuality: "Risky Entry",
    entry: lastCandle.close,
    stopLoss: lastCandle.close * 0.98,
    takeProfit: lastCandle.close * 1.04,
    riskRewardRatio: 2.0,
    psychologicalAdvice: "التزم بالهدوء. هناك مشكلة تقنية في الاتصال بالذكاء الاصطناعي، يرجى الاعتماد على تحليلك الخاص أو الانتظار."
  };
};

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route: Health Check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // API Route: Market Data (simulated using Binance public API for klines)
  app.get("/api/market", async (req, res) => {
    try {
      const symbol = req.query.symbol || 'BTCUSDT';
      const interval = req.query.interval || '15m'; // 1m, 5m, 15m, 1h, 4h
      const limit = req.query.limit || 300;
      
      const response = await fetch(`https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`);
      if (!response.ok) {
        throw new Error('Failed to fetch market data');
      }
      
      const data = await response.json();
      
      // Map binance response to lightweight charts format
      const formattedData = data.map((d: any) => ({
        time: d[0] / 1000,
        open: parseFloat(d[1]),
        high: parseFloat(d[2]),
        low: parseFloat(d[3]),
        close: parseFloat(d[4]),
        volume: parseFloat(d[5]),
        volumeDelta: parseFloat(d[4]) > parseFloat(d[1]) ? parseFloat(d[5]) : -parseFloat(d[5])
      }));

      // Calculate indicators
      const closes = formattedData.map((d: any) => d.close);
      const highs = formattedData.map((d: any) => d.high);
      const lows = formattedData.map((d: any) => d.low);
      
      const sma20 = SMA.calculate({ period: 20, values: closes });
      const sma50 = SMA.calculate({ period: 50, values: closes });
      const ema200 = EMA.calculate({ period: 200, values: closes });
      const rsi14 = RSI.calculate({ period: 14, values: closes });
      const atr14 = ATR.calculate({ period: 14, high: highs, low: lows, close: closes });
      const macd = MACD.calculate({ values: closes, fastPeriod: 12, slowPeriod: 26, signalPeriod: 9, SimpleMAOscillator: false, SimpleMASignal: false });

      // Append indicator data to the latest candles where they are available
      const dataWithIndicators = formattedData.map((d: any, i: number) => {
        return {
          ...d,
          sma20: i >= 19 ? sma20[i - 19] : null,
          sma50: i >= 49 ? sma50[i - 49] : null,
          ema200: i >= 199 ? ema200[i - 199] : null,
          rsi: i >= 14 ? rsi14[i - 14] : null,
          atr: i >= 14 ? atr14[i - 14] : null,
          macd: i >= 25 ? macd[i - 25] : null // MACD requires 26 periods but array indexing
        }
      });
      
      res.json(dataWithIndicators);
    } catch (error) {
      console.error('Market data error:', error);
      res.status(500).json({ error: "Failed to fetch market data" });
    }
  });

  // API Route: Gemini Analysis
  app.post("/api/gemini/analyze", async (req, res) => {
    try {
      const { prompt, candles, params } = req.body;
      
      if (!candles || !Array.isArray(candles) || candles.length === 0) {
        return res.status(400).json({ error: "No market data available" });
      }

      const lastCandle = candles[candles.length - 1];
      
      const highs = candles.map((c: any) => c.high);
      const lows = candles.map((c: any) => c.low);
      const closes = candles.map((c: any) => c.close);
      const atrResult = ATR.calculate({ period: 14, high: highs, low: lows, close: closes });
      const currentAtr = atrResult[atrResult.length - 1] || 0;
      
      const analyzedData = candles.slice(-30).map((c: any) => `Time: ${new Date(c.time * 1000).toISOString()}, O: ${c.open}, H: ${c.high}, L: ${c.low}, C: ${c.close}`);
      
      let modePrompt = "";
      switch (params.aiMode) {
        case "Conservative":
          modePrompt = "You are in CONSERVATIVE Mode. Give NO_TRADE very often. Only accept PERFECT setups. Protect capital at all costs.";
          break;
        case "Aggressive":
          modePrompt = "You are in AGGRESSIVE SCALPER Mode. Look for quick, short-term opportunities. Accept riskier short-term setups but strict stop loss.";
          break;
        case "SmartMoney":
          modePrompt = "You are in SMART MONEY Mode. Focus heavily on Liquidity Sweeps, Fake Breakouts, and overall Market Structure. Avoid retail traps.";
          break;
        case "AntiFomo":
          modePrompt = "You are in ANTI-FOMO COACH Mode. Focus entirely on the user's psychological state. Block any trade that smells like FOMO, revenge trading, or boredom. Give strict psychological warnings.";
          break;
        case "Sniper":
          modePrompt = "You are in SNIPER ENTRIES Mode. Only look for optimal entries. Reject late entries immediately. Wait for retests and confirmations.";
          break;
        default:
          modePrompt = "";
      }

      const fullPrompt = `You are a strict, highly professional crypto trading AI assistant named 'Trading Coach AI'. Your style is simple Egyptian Arabic, professional but harsh. You evaluate market conditions and risk.
        ${modePrompt}
        User capital: $${params.capital}, Risk: ${params.risk}%, Leverage: ${params.leverage}x
        Current pair: ${params.symbol}, Timeframe: ${params.timeframe}
        Latest Indicators: RSI=${lastCandle.rsi}, SMA20=${lastCandle.sma20}, SMA50=${lastCandle.sma50}, EMA200=${lastCandle.ema200}, VolumeDelta=${lastCandle.volumeDelta}, MACD=${lastCandle.macd?.MACD}, ATR(14)=${currentAtr}
        Market Context (Last 30 candles):\n${analyzedData.join('\n')}\n\n
        Analyze the structure, trend, and momentum.
        1. Action: LONG, SHORT, or NO_TRADE
        2. Trend: صاعد, هابط, or عرضي
        3. Momentum: قوي, ضعيف, or متوسط
        4. isTradable: boolean
        5. Trade Score: 1-10 (10 being perfect setup)
        6. Determine Psychological State and give advice.
        7. Market Structure: Identify Higher Highs (HH), Higher Lows (HL), Lower Highs (LH), Lower Lows (LL) and explain overall structure.
        8. Short Reasons: Array of short bullet points summarizing why this trade is suggested.
        9. Warnings: Determine if it's a late entry (lateEntryWarning) or bad risk/reward (badRiskRewardWarning).
        10. Win Probability: Estimate success percentage between 0 and 100 based on structure and indicators.
        11. Entry Quality: Determine entry quality as "Excellent Entry", "Good Entry", "Risky Entry", or "Late Entry". Stop Loss MUST be intelligently placed based on Support/Resistance or ATR. Take Profit must be dynamic based on SR, momentum, and risk/reward.
        12. Fake Breakout Detection: Detect Fake Breakouts, Bull Traps, Bear Traps, Liquidity Grabs based on wick rejections, volume lack, and returning to ranges. If detected, specify in fakeBreakoutWarning.
        Format as JSON.`;

      try {
        const response = await callGeminiWithFallback({
          contents: fullPrompt,
          config: {
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                action: { type: Type.STRING, description: "LONG, SHORT, or NO_TRADE" },
                decisionReason: { type: Type.STRING, description: "Detailed explanation in Arabic" },
                trend: { type: Type.STRING, description: "صاعد, هابط, or عرضي" },
                momentum: { type: Type.STRING, description: "قوي, ضعيف, or متوسط" },
                isTradable: { type: Type.BOOLEAN },
                tradeScoreOutOf10: { type: Type.NUMBER },
                currentRsi: { type: Type.NUMBER },
                shortEntryReasons: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Short bullet points explaining reasons for entry" },
                marketStructureAnalysis: { type: Type.STRING, description: "Analysis of HH, HL, LH, LL and overall structure in Arabic" },
                lateEntryWarning: { type: Type.BOOLEAN, description: "True if entry is late based on best entry point" },
                badRiskRewardWarning: { type: Type.BOOLEAN, description: "True if Risk/Reward is bad" },
                fakeBreakoutWarning: { type: Type.STRING, description: "Description of Fake Breakout, Bull/Bear Trap, Liquidity Grab if detected. Empty if none." },
                winProbabilityPercent: { type: Type.NUMBER, description: "0-100 estimate of success" },
                entryQuality: { type: Type.STRING, description: "Excellent Entry, Good Entry, Risky Entry, or Late Entry" },
                entry: { type: Type.NUMBER },
                stopLoss: { type: Type.NUMBER },
                takeProfit: { type: Type.NUMBER },
                riskRewardRatio: { type: Type.NUMBER },
                trapDetected: { type: Type.STRING, description: "E.g., Bull Trap, Bear Trap, None" },
                psychologicalAdvice: { type: Type.STRING, description: "Harsh but helpful psychological advice in Arabic" },
              },
              required: ["action", "decisionReason", "trend", "momentum", "isTradable", "tradeScoreOutOf10", "currentRsi", "entry", "stopLoss", "takeProfit", "riskRewardRatio", "psychologicalAdvice"]
            }
          }
        });
        
        const text = response.text || "{}";
        res.json(JSON.parse(text));
      } catch (fallbackError: any) {
        console.warn("[Gemini] All models failed. Providing Mock Analysis.");
        const mockData = getMockAnalysis(params, lastCandle);
        res.json(mockData);
      }
    } catch (outerError: any) {
      console.error('Fatal API Error:', outerError);
      res.status(500).json({ error: "Failed to process request" });
    }
  });
  
  // API Route: AI Chat
  app.post("/api/gemini/chat", async (req, res) => {
    try {
      const { message, context } = req.body;
      
      const prompt = `You are "Trading Coach AI". Your style is professional yet strict simple Arabic (عامية مصرية).
      You do not sugarcoat. You protect the user from reckless trading. 
      Context: ${JSON.stringify(context)}\nUser: ${message}
      `;

      try {
        const response = await callGeminiWithFallback({
          contents: prompt
        });
        
        res.json({ reply: response.text });
      } catch (fallbackError: any) {
        console.warn("[Gemini] Chat Fallback failed.");
        res.json({ reply: "عذراً، أواجه مشكلة في الاتصال بالذكاء الاصطناعي حالياً. يرجى المحاولة لاحقاً أو الاعتماد على التحليل الفني الموجود." });
      }
    } catch (outerError: any) {
      console.error('Chat Error:', outerError);
      res.status(500).json({ error: "Failed to process chat" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
